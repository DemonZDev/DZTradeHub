package online.demonzdevelopment.dztradehub.storage;

public enum StorageType {
    SQLITE,
    MYSQL,
    FLATFILE
}
