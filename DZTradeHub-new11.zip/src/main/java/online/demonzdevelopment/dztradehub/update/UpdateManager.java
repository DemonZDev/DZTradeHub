package online.demonzdevelopment.dztradehub.update;

import online.demonzdevelopment.dztradehub.DZTradeHub;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;

public class UpdateManager {
    
    private static final String GITHUB_API_URL = "https://api.github.com/repos/DemonZDev/DZTradeHub/releases";
    
    private final DZTradeHub plugin;
    private final Logger logger;
    private String latestVersion;
    private boolean autoUpdateEnabled;
    
    public UpdateManager(DZTradeHub plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
        this.autoUpdateEnabled = plugin.getConfig().getBoolean("update.auto-update", false);
        
        // Start periodic version check if enabled
        if (plugin.getConfig().getBoolean("update.check-on-start", true)) {
            checkForUpdates();
        }
        
        startPeriodicCheck();
    }
    
    /**
     * Start periodic update checking
     */
    private void startPeriodicCheck() {
        int intervalMinutes = plugin.getConfig().getInt("update.check-interval-minutes", 60);
        if (intervalMinutes <= 0) {
            return;
        }
        
        long intervalTicks = intervalMinutes * 60 * 20L;
        
        new BukkitRunnable() {
            @Override
            public void run() {
                if (plugin.getConfig().getBoolean("update.runtime-check", true)) {
                    checkForUpdates().thenAccept(hasUpdate -> {
                        if (hasUpdate && autoUpdateEnabled) {
                            logger.info("New version available! Auto-updating...");
                            // Auto-update logic would go here
                        }
                    });
                }
            }
        }.runTaskTimerAsynchronously(plugin, intervalTicks, intervalTicks);
    }
    
    /**
     * Check for updates
     */
    public CompletableFuture<Boolean> checkForUpdates() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                URL url = new URL(GITHUB_API_URL + "/latest");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                
                if (conn.getResponseCode() == 200) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    
                    // Parse JSON to get version
                    String json = response.toString();
                    int tagNameIndex = json.indexOf("\"tag_name\":");
                    if (tagNameIndex != -1) {
                        int start = json.indexOf("\"", tagNameIndex + 11) + 1;
                        int end = json.indexOf("\"", start);
                        latestVersion = json.substring(start, end).replace("v", "");
                        
                        String currentVersion = plugin.getDescription().getVersion();
                        return !currentVersion.equals(latestVersion);
                    }
                }
            } catch (Exception e) {
                logger.warning("Failed to check for updates: " + e.getMessage());
            }
            return false;
        });
    }
    
    /**
     * Get current version
     */
    public String getCurrentVersion() {
        return plugin.getDescription().getVersion();
    }
    
    /**
     * Get latest version
     */
    public String getLatestVersion() {
        return latestVersion != null ? latestVersion : getCurrentVersion();
    }
    
    /**
     * Update to latest version
     */
    public void updateToLatest(Player sender) {
        sender.sendMessage("§eChecking for latest version...");
        
        checkForUpdates().thenAccept(hasUpdate -> {
            if (hasUpdate) {
                sender.sendMessage("§aNew version found: §ev" + latestVersion);
                sender.sendMessage("§eCurrent version: §ev" + getCurrentVersion());
                sender.sendMessage("§aDownload from: §bhttps://github.com/DemonZDev/DZTradeHub/releases/latest");
                sender.sendMessage("§7Note: Place the new JAR in plugins folder and restart server");
            } else {
                sender.sendMessage("§aYou are running the latest version!");
            }
        });
    }
    
    /**
     * Update to previous version
     */
    public void updateToPrevious(Player sender) {
        sender.sendMessage("§eChecking for previous versions...");
        sender.sendMessage("§aVisit: §bhttps://github.com/DemonZDev/DZTradeHub/releases");
        sender.sendMessage("§7Download the desired version and restart server");
    }
    
    /**
     * Update to next version (for release candidates)
     */
    public void updateToNext(Player sender) {
        sender.sendMessage("§eChecking for pre-release versions...");
        sender.sendMessage("§aVisit: §bhttps://github.com/DemonZDev/DZTradeHub/releases");
        sender.sendMessage("§7Download the desired pre-release and restart server");
    }
    
    /**
     * Toggle auto-update
     */
    public void toggleAutoUpdate(Player sender) {
        autoUpdateEnabled = !autoUpdateEnabled;
        plugin.getConfig().set("update.auto-update", autoUpdateEnabled);
        plugin.saveConfig();
        
        if (autoUpdateEnabled) {
            sender.sendMessage("§aAuto-update enabled!");
            sender.sendMessage("§7The plugin will check for updates every " + 
                             plugin.getConfig().getInt("update.check-interval-minutes", 60) + " minutes");
        } else {
            sender.sendMessage("§cAuto-update disabled!");
        }
    }
}
