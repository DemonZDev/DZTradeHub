package online.demonzdevelopment.dztradehub.data;

import org.bukkit.entity.Player;

import java.util.UUID;

public class QueueEntry {
    private final UUID playerId;
    private final String playerName;
    private final long joinTime;
    private long lastActivityTime;
    private final int queueNumber;
    private boolean isActive;
    private long sessionStartTime;

    public QueueEntry(Player player, int queueNumber) {
        this.playerId = player.getUniqueId();
        this.playerName = player.getName();
        this.joinTime = System.currentTimeMillis();
        this.lastActivityTime = System.currentTimeMillis();
        this.queueNumber = queueNumber;
        this.isActive = false;
        this.sessionStartTime = 0;
    }

    public UUID getPlayerId() { return playerId; }
    public String getPlayerName() { return playerName; }
    public long getJoinTime() { return joinTime; }
    public long getLastActivityTime() { return lastActivityTime; }
    public void updateActivity() { this.lastActivityTime = System.currentTimeMillis(); }
    public int getQueueNumber() { return queueNumber; }
    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { 
        this.isActive = active;
        if (active) {
            this.sessionStartTime = System.currentTimeMillis();
        }
    }
    public long getSessionStartTime() { return sessionStartTime; }
    public long getWaitTime() { return System.currentTimeMillis() - joinTime; }
    public long getAfkTime() { return System.currentTimeMillis() - lastActivityTime; }
    public long getSessionTime() { return sessionStartTime > 0 ? System.currentTimeMillis() - sessionStartTime : 0; }
}
