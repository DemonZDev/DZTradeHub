package online.demonzdevelopment.dztradehub.commands;

import online.demonzdevelopment.dztradehub.DZTradeHub;
import online.demonzdevelopment.dztradehub.gui.CasinoMainGUI;
import online.demonzdevelopment.dztradehub.utils.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class CasinoCommand implements CommandExecutor {
    private final DZTradeHub plugin;
    private final CasinoMainGUI casinoGUI;

    public CasinoCommand(DZTradeHub plugin) {
        this.plugin = plugin;
        this.casinoGUI = new CasinoMainGUI(plugin);
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, 
                           @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }

        if (!player.hasPermission("dztradehub.casino")) {
            MessageUtil.sendError(player, "You don't have permission to use the casino!");
            return true;
        }

        // Open casino GUI
        casinoGUI.open(player);
        return true;
    }
}
