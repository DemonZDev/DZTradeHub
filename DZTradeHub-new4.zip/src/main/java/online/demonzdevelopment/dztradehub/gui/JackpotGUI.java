package online.demonzdevelopment.dztradehub.gui;

import online.demonzdevelopment.dztradehub.DZTradeHub;
import online.demonzdevelopment.dztradehub.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class JackpotGUI {
    private final DZTradeHub plugin;
    
    public JackpotGUI(DZTradeHub plugin) {
        this.plugin = plugin;
    }
    
    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, "§6§lJackpot Machine");
        
        // Money bet
        ItemStack money = new ItemStack(Material.GOLD_INGOT);
        ItemMeta moneyMeta = money.getItemMeta();
        moneyMeta.setDisplayName("§e§lBet Money");
        moneyMeta.setLore(Arrays.asList(
            "§7Spin the jackpot with money",
            "",
            "§eLeft-Click: §a100",
            "§eRight-Click: §a1000",
            "§eShift-Left: §a10000"
        ));
        money.setItemMeta(moneyMeta);
        inv.setItem(11, money);
        
        // Mobcoin bet
        ItemStack mobcoin = new ItemStack(Material.EMERALD);
        ItemMeta mobcoinMeta = mobcoin.getItemMeta();
        mobcoinMeta.setDisplayName("§a§lBet Mobcoin");
        mobcoinMeta.setLore(Arrays.asList(
            "§7Spin the jackpot with mobcoin",
            "",
            "§eLeft-Click: §a100",
            "§eRight-Click: §a1000",
            "§eShift-Left: §a10000"
        ));
        mobcoin.setItemMeta(mobcoinMeta);
        inv.setItem(13, mobcoin);
        
        // Gem bet
        ItemStack gem = new ItemStack(Material.DIAMOND);
        ItemMeta gemMeta = gem.getItemMeta();
        gemMeta.setDisplayName("§b§lBet Gem");
        gemMeta.setLore(Arrays.asList(
            "§7Spin the jackpot with gem",
            "",
            "§eLeft-Click: §a10",
            "§eRight-Click: §a100",
            "§eShift-Left: §a1000"
        ));
        gem.setItemMeta(gemMeta);
        inv.setItem(15, gem);
        
        // Info
        ItemStack info = new ItemStack(Material.BOOK);
        ItemMeta infoMeta = info.getItemMeta();
        infoMeta.setDisplayName("§6§lJackpot Info");
        infoMeta.setLore(Arrays.asList(
            "§7Match 3 symbols to win!",
            "",
            "§e7️⃣ 7️⃣ 7️⃣ §7- §a10x",
            "§e💎 💎 💎 §7- §a7x",
            "§e⭐ ⭐ ⭐ §7- §a5x",
            "§eOther matches §7- §a3x",
            "§e2 matches §7- §a1.5x"
        ));
        info.setItemMeta(infoMeta);
        inv.setItem(22, info);
        
        player.openInventory(inv);
    }
    
    public void handleClick(InventoryClickEvent event, Player player) {
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;
        
        boolean isShift = event.getClick().isShiftClick();
        boolean isRight = event.getClick().isRightClick();
        
        double amount = 0;
        String currency = "";
        
        switch (clicked.getType()) {
            case GOLD_INGOT:
                currency = "MONEY";
                amount = isShift ? 10000 : (isRight ? 1000 : 100);
                break;
            case EMERALD:
                currency = "MOBCOIN";
                amount = isShift ? 10000 : (isRight ? 1000 : 100);
                break;
            case DIAMOND:
                currency = "GEM";
                amount = isShift ? 1000 : (isRight ? 100 : 10);
                break;
            default:
                return;
        }
        
        player.closeInventory();
        plugin.getCasinoManager().performJackpotSpin(player, currency, amount);
    }
}
