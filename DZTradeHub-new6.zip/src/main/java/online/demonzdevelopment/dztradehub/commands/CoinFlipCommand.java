package online.demonzdevelopment.dztradehub.commands;

import online.demonzdevelopment.dztradehub.DZTradeHub;
import online.demonzdevelopment.dztradehub.data.CoinFlipRequest;
import online.demonzdevelopment.dztradehub.gui.CoinFlipGUI;
import online.demonzdevelopment.dztradehub.gui.CoinFlipRequestsGUI;
import online.demonzdevelopment.dztradehub.managers.CasinoManager;
import online.demonzdevelopment.dztradehub.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CoinFlipCommand implements CommandExecutor, TabCompleter {
    private final DZTradeHub plugin;
    private final CasinoManager casinoManager;
    private final CoinFlipGUI coinFlipGUI;
    private final CoinFlipRequestsGUI requestsGUI;

    public CoinFlipCommand(DZTradeHub plugin) {
        this.plugin = plugin;
        this.casinoManager = plugin.getCasinoManager();
        this.coinFlipGUI = new CoinFlipGUI(plugin);
        this.requestsGUI = new CoinFlipRequestsGUI(plugin);
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, 
                           @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }

        if (!player.hasPermission("dztradehub.casino")) {
            MessageUtil.sendError(player, "You don't have permission to use coin flip!");
            return true;
        }

        if (args.length == 0) {
            // Open GUI for mode selection
            coinFlipGUI.open(player);
            return true;
        }

        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "single" -> handleSingleMode(player, args);
            case "double" -> handleDoubleMode(player, args);
            case "accept" -> handleAccept(player);
            case "deny" -> handleDeny(player);
            case "requests" -> handleRequests(player);
            default -> sendHelp(player);
        }

        return true;
    }

    private void handleSingleMode(Player player, String[] args) {
        if (args.length < 4) {
            MessageUtil.sendError(player, "Usage: /coinflip single <money|mobcoin|gem> <amount> <head|tail>");
            return;
        }

        String currencyType = args[1].toUpperCase();
        if (!currencyType.equals("MONEY") && !currencyType.equals("MOBCOIN") && !currencyType.equals("GEM")) {
            MessageUtil.sendError(player, "Invalid currency type! Use: money, mobcoin, or gem");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(args[2]);
            if (amount <= 0) {
                MessageUtil.sendError(player, "Amount must be positive!");
                return;
            }
        } catch (NumberFormatException e) {
            MessageUtil.sendError(player, "Invalid amount!");
            return;
        }

        String sideStr = args[3].toUpperCase();
        CoinFlipRequest.CoinSide side;
        try {
            side = CoinFlipRequest.CoinSide.valueOf(sideStr);
        } catch (IllegalArgumentException e) {
            MessageUtil.sendError(player, "Invalid side! Use: head or tail");
            return;
        }

        // Perform single player coin flip
        casinoManager.performSinglePlayerCoinFlip(player, currencyType, amount, side);
    }

    private void handleDoubleMode(Player player, String[] args) {
        if (args.length < 5) {
            MessageUtil.sendError(player, "Usage: /coinflip double <player> <money|mobcoin|gem> <amount> <head|tail>");
            return;
        }

        String targetName = args[1];
        Player target = Bukkit.getPlayer(targetName);
        
        if (target == null || !target.isOnline()) {
            MessageUtil.sendError(player, "Player not found or not online!");
            return;
        }

        if (target.getUniqueId().equals(player.getUniqueId())) {
            MessageUtil.sendError(player, "You cannot challenge yourself!");
            return;
        }

        String currencyType = args[2].toUpperCase();
        if (!currencyType.equals("MONEY") && !currencyType.equals("MOBCOIN") && !currencyType.equals("GEM")) {
            MessageUtil.sendError(player, "Invalid currency type! Use: money, mobcoin, or gem");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(args[3]);
            if (amount <= 0) {
                MessageUtil.sendError(player, "Amount must be positive!");
                return;
            }
        } catch (NumberFormatException e) {
            MessageUtil.sendError(player, "Invalid amount!");
            return;
        }

        String sideStr = args[4].toUpperCase();
        CoinFlipRequest.CoinSide side;
        try {
            side = CoinFlipRequest.CoinSide.valueOf(sideStr);
        } catch (IllegalArgumentException e) {
            MessageUtil.sendError(player, "Invalid side! Use: head or tail");
            return;
        }

        // Send request
        casinoManager.sendCoinFlipRequest(player, target, currencyType, amount, side);
    }

    private void handleAccept(Player player) {
        CoinFlipRequest request = casinoManager.getLastRequest(player.getUniqueId());
        if (request == null) {
            MessageUtil.sendError(player, "You have no pending coin flip requests!");
            return;
        }

        casinoManager.acceptCoinFlipRequest(player, request);
    }

    private void handleDeny(Player player) {
        CoinFlipRequest request = casinoManager.getLastRequest(player.getUniqueId());
        if (request == null) {
            MessageUtil.sendError(player, "You have no pending coin flip requests!");
            return;
        }

        casinoManager.denyCoinFlipRequest(player, request);
    }

    private void handleRequests(Player player) {
        requestsGUI.open(player);
    }

    private void sendHelp(Player player) {
        player.sendMessage("§6§lCoin Flip Commands:");
        player.sendMessage("§e/coinflip §7- Open coin flip GUI");
        player.sendMessage("§e/coinflip single <money|mobcoin|gem> <amount> <head|tail> §7- Single player mode");
        player.sendMessage("§e/coinflip double <player> <money|mobcoin|gem> <amount> <head|tail> §7- Challenge a player");
        player.sendMessage("§e/coinflip accept §7- Accept latest request");
        player.sendMessage("§e/coinflip deny §7- Deny latest request");
        player.sendMessage("§e/coinflip requests §7- View all pending requests");
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, 
                                                @NotNull String alias, @NotNull String[] args) {
        List<String> completions = new ArrayList<>();
        
        if (args.length == 1) {
            completions.addAll(Arrays.asList("single", "double", "accept", "deny", "requests"));
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("single")) {
                completions.addAll(Arrays.asList("money", "mobcoin", "gem"));
            } else if (args[0].equalsIgnoreCase("double")) {
                // List online players
                Bukkit.getOnlinePlayers().forEach(p -> completions.add(p.getName()));
            }
        } else if (args.length == 3) {
            if (args[0].equalsIgnoreCase("double")) {
                completions.addAll(Arrays.asList("money", "mobcoin", "gem"));
            }
        } else if (args.length == 4 && args[0].equalsIgnoreCase("single")) {
            completions.addAll(Arrays.asList("head", "tail"));
        } else if (args.length == 5 && args[0].equalsIgnoreCase("double")) {
            completions.addAll(Arrays.asList("head", "tail"));
        }
        
        return completions;
    }
}
