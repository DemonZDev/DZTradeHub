package online.demonzdevelopment.dztradehub.gui;

import net.kyori.adventure.text.Component;
import online.demonzdevelopment.dztradehub.DZTradeHub;
import online.demonzdevelopment.dztradehub.data.Auction;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class AuctionBrowserGUI {
    private final DZTradeHub plugin;

    public static class AuctionHolder implements InventoryHolder {
        private int page;

        public AuctionHolder(int page) {
            this.page = page;
        }

        public int getPage() { return page; }

        @Override
        public Inventory getInventory() { return null; }
    }

    public AuctionBrowserGUI(DZTradeHub plugin) {
        this.plugin = plugin;
    }

    public void openBrowser(Player player) {
        openBrowser(player, 0);
    }

    public void openBrowser(Player player, int page) {
        Inventory inv = Bukkit.createInventory(
            new AuctionHolder(page),
            54,
            Component.text("§6Auction House")
        );

        // Get auctions for this page
        List<Auction> auctions = plugin.getAuctionManager().getAllAuctions();
        int startIndex = page * 36;
        int endIndex = Math.min(startIndex + 36, auctions.size());

        // Fill auction items (slots 9-44)
        for (int i = startIndex; i < endIndex; i++) {
            Auction auction = auctions.get(i);
            ItemStack display = createAuctionDisplay(auction);
            inv.setItem(9 + (i - startIndex), display);
        }

        // Previous page (slot 45)
        if (page > 0) {
            ItemStack prev = new ItemStack(Material.ARROW);
            ItemMeta prevMeta = prev.getItemMeta();
            prevMeta.displayName(Component.text("§ePrevious Page"));
            prev.setItemMeta(prevMeta);
            inv.setItem(45, prev);
        }

        // My Auctions (slot 49)
        ItemStack myAuctions = new ItemStack(Material.BOOK);
        ItemMeta myMeta = myAuctions.getItemMeta();
        myMeta.displayName(Component.text("§eMy Auctions"));
        myAuctions.setItemMeta(myMeta);
        inv.setItem(49, myAuctions);

        // Next page (slot 53)
        if (endIndex < auctions.size()) {
            ItemStack next = new ItemStack(Material.ARROW);
            ItemMeta nextMeta = next.getItemMeta();
            nextMeta.displayName(Component.text("§eNext Page"));
            next.setItemMeta(nextMeta);
            inv.setItem(53, next);
        }

        player.openInventory(inv);
    }

    private ItemStack createAuctionDisplay(Auction auction) {
        ItemStack display = auction.getItemStack().clone();
        ItemMeta meta = display.getItemMeta();
        
        List<Component> lore = new ArrayList<>();
        if (meta.hasLore()) {
            lore.addAll(meta.lore());
        }
        
        lore.add(Component.text(""));
        
        double currentPrice = auction.getCurrentPrice();
        lore.add(Component.text("§7Current Price: §a$" + String.format("%.2f", currentPrice)));
        
        if (auction.getDropPerUnit() > 0) {
            lore.add(Component.text("§7Type: §ePri ce Reduction"));
            lore.add(Component.text("§7Drops: §e$" + auction.getDropPerUnit() + " per " + 
                auction.getDropIntervalHours() + "h"));
        }
        
        if (auction.getMaxQueue() > 0) {
            lore.add(Component.text("§7Type: §eBidding Queue"));
            lore.add(Component.text("§7Queue: §e" + auction.getQueueSize() + "/" + auction.getMaxQueue()));
        }
        
        if (auction.isFrozen()) {
            lore.add(Component.text("§c§lFROZEN"));
        }
        
        lore.add(Component.text(""));
        lore.add(Component.text("§eClick to purchase"));
        
        meta.lore(lore);
        display.setItemMeta(meta);
        return display;
    }
}