package online.demonzdevelopment.dztradehub.gui;

import online.demonzdevelopment.dztradehub.DZTradeHub;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class CoinFlipGUI {
    private final DZTradeHub plugin;
    
    public CoinFlipGUI(DZTradeHub plugin) {
        this.plugin = plugin;
    }
    
    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, "§e§lCoin Flip");
        
        // Single Player
        ItemStack single = new ItemStack(Material.GOLD_INGOT);
        ItemMeta singleMeta = single.getItemMeta();
        singleMeta.setDisplayName("§e§lSingle Player");
        singleMeta.setLore(Arrays.asList(
            "§7Play against the house",
            "§7Win 2x your bet!",
            "",
            "§eUse command:",
            "§7/coinflip single <currency> <amount> <head|tail>"
        ));
        single.setItemMeta(singleMeta);
        inv.setItem(11, single);
        
        // Double Player
        ItemStack doublePlayer = new ItemStack(Material.DIAMOND);
        ItemMeta doubleMeta = doublePlayer.getItemMeta();
        doubleMeta.setDisplayName("§b§lDouble Player");
        doubleMeta.setLore(Arrays.asList(
            "§7Challenge another player",
            "§7Winner takes all!",
            "",
            "§eUse command:",
            "§7/coinflip double <player> <currency> <amount> <head|tail>"
        ));
        doublePlayer.setItemMeta(doubleMeta);
        inv.setItem(15, doublePlayer);
        
        player.openInventory(inv);
    }
}
