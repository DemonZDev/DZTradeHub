package online.demonzdevelopment.dztradehub.storage;

import online.demonzdevelopment.dztradehub.DZTradeHub;
import online.demonzdevelopment.dztradehub.data.Area;
import online.demonzdevelopment.dztradehub.data.Shop;
import online.demonzdevelopment.dztradehub.data.ShopItem;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileStorageManager {
    private final DZTradeHub plugin;
    private final File areasFolder;

    public FileStorageManager(DZTradeHub plugin) {
        this.plugin = plugin;
        this.areasFolder = new File(plugin.getDataFolder(), "Areas");
        if (!areasFolder.exists()) {
            areasFolder.mkdirs();
        }
    }

    public void saveArea(Area area) {
        File areaFolder = new File(areasFolder, area.getName());
        if (!areaFolder.exists()) {
            areaFolder.mkdirs();
        }

        File areaFile = new File(areaFolder, area.getName() + ".yml");
        YamlConfiguration config = new YamlConfiguration();

        config.set("name", area.getName());
        config.set("displayName", area.getDisplayName());
        config.set("type", area.getType().name());
        config.set("description", area.getDescription());
        
        if (area.getLocation() != null) {
            config.set("location.world", area.getLocation().getWorld().getName());
            config.set("location.x", area.getLocation().getX());
            config.set("location.y", area.getLocation().getY());
            config.set("location.z", area.getLocation().getZ());
        }

        try {
            config.save(areaFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save area: " + area.getName());
            e.printStackTrace();
        }
    }

    public void saveShop(String areaName, Shop shop) {
        File areaFolder = new File(areasFolder, areaName);
        File shopsFolder = new File(areaFolder, "Shops");
        File shopFolder = new File(shopsFolder, shop.getName());
        
        if (!shopFolder.exists()) {
            shopFolder.mkdirs();
        }

        File shopFile = new File(shopFolder, shop.getName().toLowerCase() + ".yml");
        YamlConfiguration config = new YamlConfiguration();

        config.set("name", shop.getName());
        config.set("displayName", shop.getDisplayName());
        config.set("shopType", shop.getShopType().name());
        config.set("queueType", shop.getQueueType().name());
        
        // Reception settings
        config.set("reception.enabled", shop.isReceptionEnabled());
        config.set("reception.number", shop.getReceptionNumber());
        config.set("reception.timeKick", shop.getReceptionTimeKick());
        config.set("reception.afkKick", shop.getReceptionAfkKick());
        
        // Checkout settings
        config.set("checkout.enabled", shop.isCheckoutEnabled());
        config.set("checkout.number", shop.getCheckoutNumber());
        config.set("checkout.timeKick", shop.getCheckoutTimeKick());
        
        // Stock settings
        config.set("stock.linkedShop", shop.getLinkedShopName());
        config.set("stock.restockInterval", shop.getRestockInterval());
        config.set("stock.restockAmount", shop.getRestockAmount());

        try {
            config.save(shopFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save shop: " + shop.getName());
            e.printStackTrace();
        }
    }

    public void saveShopItems(String areaName, Shop shop) {
        File areaFolder = new File(areasFolder, areaName);
        File shopsFolder = new File(areaFolder, "Shops");
        File shopFolder = new File(shopsFolder, shop.getName());
        File itemsFile = new File(shopFolder, "items.yml");

        YamlConfiguration config = new YamlConfiguration();

        int index = 0;
        for (ShopItem item : shop.getItems()) {
            String path = "items." + index;
            config.set(path + ".material", item.getItemStack().getType().name());
            config.set(path + ".amount", item.getItemStack().getAmount());
            config.set(path + ".currency", item.getCurrency().name());
            config.set(path + ".minPrice", item.getMinPrice());
            config.set(path + ".maxPrice", item.getMaxPrice());
            config.set(path + ".currentBuyPrice", item.getBuyPrice());
            config.set(path + ".currentSellPrice", item.getSellPrice());
            config.set(path + ".transactionType", item.getTransactionType().name());
            config.set(path + ".currentStock", item.getCurrentStock());
            config.set(path + ".maxStock", item.getMaxStock());
            config.set(path + ".dynamicPricing", item.isDynamicPricingEnabled());
            index++;
        }

        try {
            config.save(itemsFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save items for shop: " + shop.getName());
            e.printStackTrace();
        }
    }

    public Area loadArea(String areaName) {
        File areaFolder = new File(areasFolder, areaName);
        File areaFile = new File(areaFolder, areaName + ".yml");

        if (!areaFile.exists()) {
            return null;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(areaFile);
        
        Area area = new Area(
            config.getString("name"),
            config.getString("displayName"),
            Area.AreaType.valueOf(config.getString("type")),
            null // Location loaded separately if needed
        );
        
        area.setDescription(config.getStringList("description"));
        return area;
    }

    public Shop loadShop(String areaName, String shopName) {
        File areaFolder = new File(areasFolder, areaName);
        File shopsFolder = new File(areaFolder, "Shops");
        File shopFolder = new File(shopsFolder, shopName);
        File shopFile = new File(shopFolder, shopName.toLowerCase() + ".yml");

        if (!shopFile.exists()) {
            return null;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(shopFile);
        
        Shop shop = new Shop(
            config.getString("name"),
            config.getString("displayName"),
            Shop.ShopType.valueOf(config.getString("shopType"))
        );
        
        shop.setQueueType(Shop.QueueType.valueOf(config.getString("queueType", "NONE")));
        
        // Load reception settings
        shop.setReceptionEnabled(config.getBoolean("reception.enabled", false));
        shop.setReceptionNumber(config.getInt("reception.number", 1));
        shop.setReceptionTimeKick(config.getInt("reception.timeKick", 300));
        shop.setReceptionAfkKick(config.getInt("reception.afkKick", 60));
        
        // Load checkout settings
        shop.setCheckoutEnabled(config.getBoolean("checkout.enabled", false));
        shop.setCheckoutNumber(config.getInt("checkout.number", 3));
        shop.setCheckoutTimeKick(config.getInt("checkout.timeKick", 5));
        
        // Load stock settings
        shop.setLinkedShopName(config.getString("stock.linkedShop"));
        shop.setRestockInterval(config.getString("stock.restockInterval", "DAILY"));
        shop.setRestockAmount(config.getInt("stock.restockAmount", 64));
        
        return shop;
    }

    public List<ShopItem> loadShopItems(String areaName, String shopName) {
        File areaFolder = new File(areasFolder, areaName);
        File shopsFolder = new File(areaFolder, "Shops");
        File shopFolder = new File(shopsFolder, shopName);
        File itemsFile = new File(shopFolder, "items.yml");

        List<ShopItem> items = new ArrayList<>();

        if (!itemsFile.exists()) {
            return items;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(itemsFile);
        ConfigurationSection itemsSection = config.getConfigurationSection("items");

        if (itemsSection != null) {
            for (String key : itemsSection.getKeys(false)) {
                String path = "items." + key;
                Material material = Material.valueOf(config.getString(path + ".material"));
                int amount = config.getInt(path + ".amount", 1);
                ItemStack itemStack = new ItemStack(material, amount);

                ShopItem item = new ShopItem(
                    itemStack,
                    config.getDouble(path + ".currentBuyPrice"),
                    config.getDouble(path + ".currentSellPrice")
                );

                item.setCurrency(ShopItem.Currency.valueOf(config.getString(path + ".currency", "MONEY")));
                item.setMinPrice(config.getDouble(path + ".minPrice"));
                item.setMaxPrice(config.getDouble(path + ".maxPrice"));
                item.setTransactionType(ShopItem.TransactionType.valueOf(config.getString(path + ".transactionType")));
                item.setCurrentStock(config.getInt(path + ".currentStock"));
                item.setMaxStock(config.getInt(path + ".maxStock", 640));
                item.setDynamicPricingEnabled(config.getBoolean(path + ".dynamicPricing", false));

                items.add(item);
            }
        }

        return items;
    }

    public List<String> getAllAreaNames() {
        List<String> areaNames = new ArrayList<>();
        File[] files = areasFolder.listFiles(File::isDirectory);
        if (files != null) {
            for (File file : files) {
                areaNames.add(file.getName());
            }
        }
        return areaNames;
    }

    public List<String> getAllShopNames(String areaName) {
        List<String> shopNames = new ArrayList<>();
        File areaFolder = new File(areasFolder, areaName);
        File shopsFolder = new File(areaFolder, "Shops");
        
        if (shopsFolder.exists()) {
            File[] files = shopsFolder.listFiles(File::isDirectory);
            if (files != null) {
                for (File file : files) {
                    shopNames.add(file.getName());
                }
            }
        }
        return shopNames;
    }

    public void deleteArea(String areaName) {
        File areaFolder = new File(areasFolder, areaName);
        deleteDirectory(areaFolder);
    }

    public void deleteShop(String areaName, String shopName) {
        File areaFolder = new File(areasFolder, areaName);
        File shopsFolder = new File(areaFolder, "Shops");
        File shopFolder = new File(shopsFolder, shopName);
        deleteDirectory(shopFolder);
    }

    private void deleteDirectory(File directory) {
        if (directory.exists()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        deleteDirectory(file);
                    } else {
                        file.delete();
                    }
                }
            }
            directory.delete();
        }
    }
}
