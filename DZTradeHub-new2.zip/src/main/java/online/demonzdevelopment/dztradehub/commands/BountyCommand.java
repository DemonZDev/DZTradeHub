package online.demonzdevelopment.dztradehub.commands;

import online.demonzdevelopment.dztradehub.DZTradeHub;
import online.demonzdevelopment.dztradehub.data.Bounty;
import online.demonzdevelopment.dztradehub.gui.BountyGUI;
import online.demonzdevelopment.dztradehub.managers.BountyManager;
import online.demonzdevelopment.dztradehub.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BountyCommand implements CommandExecutor, TabCompleter {
    private final DZTradeHub plugin;
    private final BountyManager bountyManager;
    private final BountyGUI bountyGUI;

    public BountyCommand(DZTradeHub plugin) {
        this.plugin = plugin;
        this.bountyManager = plugin.getBountyManager();
        this.bountyGUI = new BountyGUI(plugin);
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, 
                           @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }

        if (!player.hasPermission("dztradehub.bounty")) {
            MessageUtil.sendError(player, "You don't have permission to use bounty commands!");
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "add" -> handleAdd(player, args);
            case "remove" -> handleRemove(player, args);
            case "list" -> handleList(player);
            default -> sendHelp(player);
        }

        return true;
    }

    private void handleAdd(Player player, String[] args) {
        if (args.length < 2) {
            MessageUtil.sendError(player, "Usage: /bounty add <player>");
            return;
        }

        String targetName = args[1];
        Player target = Bukkit.getPlayer(targetName);
        
        if (target == null) {
            // Try to get offline player UUID
            @SuppressWarnings("deprecation")
            org.bukkit.OfflinePlayer offlineTarget = Bukkit.getOfflinePlayer(targetName);
            
            if (!offlineTarget.hasPlayedBefore()) {
                MessageUtil.sendError(player, "Player not found!");
                return;
            }
            
            // Open bounty GUI with offline player
            bountyGUI.openForTarget(player, offlineTarget.getUniqueId(), offlineTarget.getName());
            return;
        }

        if (target.getUniqueId().equals(player.getUniqueId())) {
            MessageUtil.sendError(player, "You cannot place a bounty on yourself!");
            return;
        }

        // Open bounty GUI
        bountyGUI.openForTarget(player, target.getUniqueId(), target.getName());
    }

    private void handleRemove(Player player, String[] args) {
        if (args.length < 2) {
            MessageUtil.sendError(player, "Usage: /bounty remove <player>");
            return;
        }

        String targetName = args[1];
        @SuppressWarnings("deprecation")
        org.bukkit.OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
        
        if (!target.hasPlayedBefore()) {
            MessageUtil.sendError(player, "Player not found!");
            return;
        }

        // Remove bounties created by this player
        bountyManager.removeBounties(target.getUniqueId(), player.getUniqueId()).thenAccept(success -> {
            if (success) {
                MessageUtil.sendSuccess(player, "Removed your bounty on " + targetName);
            } else {
                MessageUtil.sendError(player, "You don't have any bounties on " + targetName);
            }
        });
    }

    private void handleList(Player player) {
        var allBounties = bountyManager.getAllBounties();
        
        if (allBounties.isEmpty()) {
            MessageUtil.sendInfo(player, "There are no active bounties.");
            return;
        }

        player.sendMessage("§6§l=== Active Bounties ===");
        allBounties.forEach((targetUUID, bounties) -> {
            @SuppressWarnings("deprecation")
            org.bukkit.OfflinePlayer target = Bukkit.getOfflinePlayer(targetUUID);
            double totalMoney = bounties.stream().mapToDouble(Bounty::getMoneyReward).sum();
            double totalMobcoin = bounties.stream().mapToDouble(Bounty::getMobcoinReward).sum();
            double totalGem = bounties.stream().mapToDouble(Bounty::getGemReward).sum();
            int totalItems = bounties.stream().mapToInt(b -> b.getRewardItems().size()).sum();
            
            player.sendMessage("§e" + target.getName() + " §7- §a" + totalMoney + " money, " + 
                             totalMobcoin + " mobcoin, " + totalGem + " gem, " + totalItems + " items");
        });
    }

    private void sendHelp(Player player) {
        player.sendMessage("§6§lBounty Commands:");
        player.sendMessage("§e/bounty add <player> §7- Place a bounty on a player (opens GUI)");
        player.sendMessage("§e/bounty remove <player> §7- Remove your bounty on a player");
        player.sendMessage("§e/bounty list §7- List all active bounties");
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, 
                                                @NotNull String alias, @NotNull String[] args) {
        List<String> completions = new ArrayList<>();
        
        if (args.length == 1) {
            completions.addAll(Arrays.asList("add", "remove", "list"));
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("add") || args[0].equalsIgnoreCase("remove"))) {
            Bukkit.getOnlinePlayers().forEach(p -> completions.add(p.getName()));
        }
        
        return completions;
    }
}
