package online.demonzdevelopment.dztradehub.managers;

import online.demonzdevelopment.dztradehub.DZTradeHub;
import online.demonzdevelopment.dztradehub.data.Kit;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.CompletableFuture;

public class KitManager {
    private final DZTradeHub plugin;
    private final Map<String, Kit> kits;

    public KitManager(DZTradeHub plugin) {
        this.plugin = plugin;
        this.kits = new HashMap<>();
        loadKits();
    }

    public void loadKits() {
        kits.clear();
        kits.putAll(plugin.getConfigManager().loadKits());
        plugin.getLogger().info("Loaded " + kits.size() + " kits");
    }

    public Kit getKit(String name) {
        return kits.get(name);
    }

    public Collection<Kit> getAllKits() {
        return kits.values();
    }

    public CompletableFuture<Boolean> canClaimKit(Player player, Kit kit) {
        return plugin.getDatabaseManager().getKitCooldownAsync(player.getUniqueId(), kit.getName())
            .thenApply(lastClaim -> {
                if (lastClaim == 0) return true;
                long elapsed = System.currentTimeMillis() - lastClaim;
                return elapsed >= (kit.getCooldown() * 1000);
            });
    }

    public CompletableFuture<Long> getRemainingCooldown(Player player, Kit kit) {
        return plugin.getDatabaseManager().getKitCooldownAsync(player.getUniqueId(), kit.getName())
            .thenApply(lastClaim -> {
                if (lastClaim == 0) return 0L;
                long elapsed = System.currentTimeMillis() - lastClaim;
                long remaining = (kit.getCooldown() * 1000) - elapsed;
                return Math.max(0, remaining / 1000); // Return seconds
            });
    }

    public void giveKit(Player player, Kit kit) {
        // Give items
        kit.getItems().forEach(item -> {
            if (player.getInventory().firstEmpty() != -1) {
                player.getInventory().addItem(item);
            } else {
                player.getWorld().dropItem(player.getLocation(), item);
            }
        });

        // Execute commands
        kit.getCommands().forEach(cmd -> {
            String command = cmd.replace("%player%", player.getName());
            plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), command);
        });

        // Set cooldown
        plugin.getDatabaseManager().setKitCooldownAsync(
            player.getUniqueId(), 
            kit.getName(), 
            System.currentTimeMillis()
        );
    }
}