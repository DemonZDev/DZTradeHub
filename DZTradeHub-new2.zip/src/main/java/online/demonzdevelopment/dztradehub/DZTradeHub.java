package online.demonzdevelopment.dztradehub;

import online.demonzdevelopment.dztradehub.api.DZTradeHubAPI;
import online.demonzdevelopment.dztradehub.commands.AuctionHouseCommand;
import online.demonzdevelopment.dztradehub.commands.TradeHubCommand;
import online.demonzdevelopment.dztradehub.data.Area;
import online.demonzdevelopment.dztradehub.data.Shop;
import online.demonzdevelopment.dztradehub.database.DatabaseManager;
import online.demonzdevelopment.dztradehub.gui.AuctionBrowserGUI;
import online.demonzdevelopment.dztradehub.gui.ShopGUI;
import online.demonzdevelopment.dztradehub.listeners.AuctionGUIListener;
import online.demonzdevelopment.dztradehub.listeners.ShopGUIListener;
import online.demonzdevelopment.dztradehub.managers.*;
import online.demonzdevelopment.dztradehub.utils.ConfigManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;

public class DZTradeHub extends JavaPlugin {
    
    // Managers
    private ConfigManager configManager;
    private DatabaseManager databaseManager;
    private ShopManager shopManager;
    private PermissionManager permissionManager;
    private KitManager kitManager;
    private AuctionManager auctionManager;
    private QueueManager queueManager;
    private CasinoManager casinoManager;
    private BountyManager bountyManager;
    private online.demonzdevelopment.dztradehub.update.UpdateManager updateManager;
    private online.demonzdevelopment.dztradehub.storage.FileStorageManager fileStorageManager;
    private StockManager stockManager;
    private DynamicPricingManager dynamicPricingManager;
    
    // GUIs
    private ShopGUI shopGUI;
    private AuctionBrowserGUI auctionBrowserGUI;
    private online.demonzdevelopment.dztradehub.gui.BountyGUI bountyGUI;
    
    // API
    private DZTradeHubAPI api;
    private online.demonzdevelopment.dzeconomy.api.DZEconomyAPI economyAPI;
    
    @Override
    public void onEnable() {
        getLogger().info("§6========================================");
        getLogger().info("§e  DZTradeHub v1.0.0");
        getLogger().info("§e  Developer: DemonZDev");
        getLogger().info("§6========================================");
        
        // Check for DZEconomy
        if (!setupEconomy()) {
            getLogger().severe("DZEconomy not found! Disabling plugin...");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        
        // Initialize managers
        configManager = new ConfigManager(this);
        databaseManager = new DatabaseManager(this);
        fileStorageManager = new online.demonzdevelopment.dztradehub.storage.FileStorageManager(this);
        shopManager = new ShopManager(this);
        permissionManager = new PermissionManager(this);
        kitManager = new KitManager(this);
        auctionManager = new AuctionManager(this);
        queueManager = new QueueManager(this);
        casinoManager = new CasinoManager(this);
        bountyManager = new BountyManager(this);
        updateManager = new online.demonzdevelopment.dztradehub.update.UpdateManager(this);
        stockManager = new StockManager(this);
        dynamicPricingManager = new DynamicPricingManager(this);
        
        // Initialize GUIs
        shopGUI = new ShopGUI(this);
        auctionBrowserGUI = new AuctionBrowserGUI(this);
        bountyGUI = new online.demonzdevelopment.dztradehub.gui.BountyGUI(this);
        
        // Initialize API
        api = new DZTradeHubAPI(this);
        
        // Register commands
        getCommand("dzth").setExecutor(new TradeHubCommand(this));
        getCommand("ah").setExecutor(new AuctionHouseCommand(this));
        getCommand("casino").setExecutor(new online.demonzdevelopment.dztradehub.commands.CasinoCommand(this));
        getCommand("coinflip").setExecutor(new online.demonzdevelopment.dztradehub.commands.CoinFlipCommand(this));
        getCommand("bounty").setExecutor(new online.demonzdevelopment.dztradehub.commands.BountyCommand(this));
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new ShopGUIListener(this), this);
        getServer().getPluginManager().registerEvents(new AuctionGUIListener(this), this);
        getServer().getPluginManager().registerEvents(new online.demonzdevelopment.dztradehub.listeners.CasinoGUIListener(this), this);
        getServer().getPluginManager().registerEvents(new online.demonzdevelopment.dztradehub.listeners.BountyListener(this), this);
        
        // Load existing areas and shops from file storage
        loadAreasFromStorage();
        
        // Setup default areas and shops if first run
        if (shopManager.getAllAreas().isEmpty()) {
            setupDefaultAreas();
        }
        
        // Start scheduled tasks
        startScheduledTasks();
        
        getLogger().info("§aDZTradeHub enabled successfully!");
    }
    
    @Override
    public void onDisable() {
        // Close database connections
        if (databaseManager != null) {
            databaseManager.close();
        }
        
        getLogger().info("§cDZTradeHub disabled!");
    }
    
    private boolean setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("DZEconomy") == null) {
            return false;
        }
        
        try {
            economyAPI = Bukkit.getServicesManager()
                .getRegistration(online.demonzdevelopment.dzeconomy.api.DZEconomyAPI.class)
                .getProvider();
            getLogger().info("§aSuccessfully hooked into DZEconomy!");
            return true;
        } catch (Exception e) {
            getLogger().severe("Failed to hook into DZEconomy: " + e.getMessage());
            return false;
        }
    }
    
    private void loadAreasFromStorage() {
        for (String areaName : fileStorageManager.getAllAreaNames()) {
            Area area = fileStorageManager.loadArea(areaName);
            if (area != null) {
                shopManager.registerArea(area);
                
                // Load shops in this area
                for (String shopName : fileStorageManager.getAllShopNames(areaName)) {
                    Shop shop = fileStorageManager.loadShop(areaName, shopName);
                    if (shop != null) {
                        shopManager.registerShop(areaName, shop);
                        
                        // Load items for this shop
                        shop.getItems().clear();
                        shop.getItems().addAll(fileStorageManager.loadShopItems(areaName, shopName));
                    }
                }
            }
        }
        getLogger().info("§aLoaded " + shopManager.getAllAreas().size() + " areas from storage");
    }
    
    private void setupDefaultAreas() {
        getLogger().info("§eCreating default areas and shops...");
        
        Location defaultLoc = new Location(getServer().getWorlds().get(0), 0, 64, 0);
        
        // Setup default areas with their shops
        DefaultShopsSetup.createSuperMarket(this, defaultLoc);
        DefaultShopsSetup.createBazar(this, defaultLoc);
        DefaultShopsSetup.createPawnShop(this, defaultLoc);
        DefaultShopsSetup.createJunkyard(this, defaultLoc);
        DefaultShopsSetup.createBlackMarket(this, defaultLoc);
        DefaultShopsSetup.createKitsArea(this, defaultLoc);
        
        getLogger().info("§aDefault areas created successfully!");
    }
    
    private void startScheduledTasks() {
        // Update auction prices every hour
        getServer().getScheduler().runTaskTimer(this, () -> {
            auctionManager.updatePrices();
        }, 0L, 72000L); // 72000 ticks = 1 hour
        
        // Check expired auctions every 6 hours
        getServer().getScheduler().runTaskTimer(this, () -> {
            auctionManager.checkExpiredAuctions();
        }, 0L, 432000L); // 432000 ticks = 6 hours
        
        // Update dynamic pricing every 30 minutes
        getServer().getScheduler().runTaskTimer(this, () -> {
            dynamicPricingManager.updateAllPrices();
        }, 0L, 36000L); // 36000 ticks = 30 minutes
        
        // Process stock restocking every hour
        getServer().getScheduler().runTaskTimer(this, () -> {
            stockManager.processRestocking();
        }, 0L, 72000L); // 72000 ticks = 1 hour
        
        getLogger().info("§aScheduled tasks started!");
    }
    
    // Getters for managers
    public ConfigManager getConfigManager() { return configManager; }
    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public ShopManager getShopManager() { return shopManager; }
    public PermissionManager getPermissionManager() { return permissionManager; }
    public KitManager getKitManager() { return kitManager; }
    public AuctionManager getAuctionManager() { return auctionManager; }
    public QueueManager getQueueManager() { return queueManager; }
    public CasinoManager getCasinoManager() { return casinoManager; }
    public BountyManager getBountyManager() { return bountyManager; }
    public online.demonzdevelopment.dztradehub.update.UpdateManager getUpdateManager() { return updateManager; }
    public online.demonzdevelopment.dztradehub.storage.FileStorageManager getFileStorageManager() { return fileStorageManager; }
    public StockManager getStockManager() { return stockManager; }
    public DynamicPricingManager getDynamicPricingManager() { return dynamicPricingManager; }
    
    // Getters for GUIs
    public ShopGUI getShopGUI() { return shopGUI; }
    public AuctionBrowserGUI getAuctionBrowserGUI() { return auctionBrowserGUI; }
    public online.demonzdevelopment.dztradehub.gui.BountyGUI getBountyGUI() { return bountyGUI; }
    
    // Getters for APIs
    public DZTradeHubAPI getAPI() { return api; }
    public online.demonzdevelopment.dzeconomy.api.DZEconomyAPI getEconomyAPI() { return economyAPI; }
}
