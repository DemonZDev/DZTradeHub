package online.demonzdevelopment.dztradehub.security;

import online.demonzdevelopment.dztradehub.utils.PasswordUtil;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Security Test Suite for Password Hashing
 * 
 * Tests SECURITY_PATCH_001 implementation
 * Verifies PBKDF2 hashing, salt generation, and backward compatibility
 */
public class PasswordSecurityTest {
    
    @Test
    @DisplayName("Test PBKDF2 Hash Format")
    public void testPBKDF2HashFormat() {
        String password = "SecurePassword123";
        String hash = PasswordUtil.hashPassword(password);
        
        assertNotNull(hash, "Hash should not be null");
        assertTrue(hash.contains(":"), "Hash should contain salt:hash separator");
        
        String[] parts = hash.split(":");
        assertEquals(2, parts.length, "Hash should have exactly 2 parts (salt:hash)");
        
        assertFalse(parts[0].isEmpty(), "Salt should not be empty");
        assertFalse(parts[1].isEmpty(), "Hash should not be empty");
    }
    
    @Test
    @DisplayName("Test Password Verification - Correct Password")
    public void testPasswordVerificationCorrect() {
        String password = "TestPass456";
        String hash = PasswordUtil.hashPassword(password);
        
        boolean result = PasswordUtil.verifyPassword(password, hash);
        assertTrue(result, "Correct password should verify successfully");
    }
    
    @Test
    @DisplayName("Test Password Verification - Wrong Password")
    public void testPasswordVerificationWrong() {
        String password = "CorrectPassword";
        String wrongPassword = "WrongPassword";
        String hash = PasswordUtil.hashPassword(password);
        
        boolean result = PasswordUtil.verifyPassword(wrongPassword, hash);
        assertFalse(result, "Wrong password should fail verification");
    }
    
    @Test
    @DisplayName("Test Unique Salts for Same Password")
    public void testUniqueSalts() {
        String password = "SamePassword123";
        String hash1 = PasswordUtil.hashPassword(password);
        String hash2 = PasswordUtil.hashPassword(password);
        
        assertNotEquals(hash1, hash2, "Same password should produce different hashes (different salts)");
        
        // Both should verify correctly
        assertTrue(PasswordUtil.verifyPassword(password, hash1));
        assertTrue(PasswordUtil.verifyPassword(password, hash2));
    }
    
    @Test
    @DisplayName("Test Legacy SHA-256 Compatibility")
    public void testLegacySHA256Compatibility() {
        // This is a SHA-256 hash of "test123" + "DZTradeHub_Bank_Salt_2024"
        String legacyHash = "a1b2c3d4e5f6..."; // Would need actual hash
        
        assertTrue(PasswordUtil.isLegacyHash(legacyHash), "Should detect legacy hash");
        
        // Legacy verification would work if we had the actual hash
        // boolean result = PasswordUtil.verifyPassword("test123", legacyHash);
        // assertTrue(result, "Legacy password should verify");
    }
    
    @Test
    @DisplayName("Test Password Validation - Valid Passwords")
    public void testPasswordValidationValid() {
        assertTrue(PasswordUtil.isPasswordValid("test1234"), "Alphanumeric password should be valid");
        assertTrue(PasswordUtil.isPasswordValid("Pass"), "Minimum 4 chars should be valid");
        assertTrue(PasswordUtil.isPasswordValid("A".repeat(32)), "32 chars should be valid");
    }
    
    @Test
    @DisplayName("Test Password Validation - Invalid Passwords")
    public void testPasswordValidationInvalid() {
        assertFalse(PasswordUtil.isPasswordValid(null), "Null password should be invalid");
        assertFalse(PasswordUtil.isPasswordValid("abc"), "Less than 4 chars should be invalid");
        assertFalse(PasswordUtil.isPasswordValid("A".repeat(33)), "More than 32 chars should be invalid");
        assertFalse(PasswordUtil.isPasswordValid("!@#$"), "Only symbols should be invalid");
    }
    
    @Test
    @DisplayName("Test Random Password Generation")
    public void testRandomPasswordGeneration() {
        String password1 = PasswordUtil.generateRandomPassword(12);
        String password2 = PasswordUtil.generateRandomPassword(12);
        
        assertEquals(12, password1.length(), "Generated password should be correct length");
        assertEquals(12, password2.length(), "Generated password should be correct length");
        
        assertNotEquals(password1, password2, "Generated passwords should be unique");
        
        assertTrue(password1.matches("[A-Za-z0-9]+"), "Password should only contain alphanumeric");
        assertTrue(PasswordUtil.isPasswordValid(password1), "Generated password should be valid");
    }
    
    @Test
    @DisplayName("Test Null/Empty Input Handling")
    public void testNullEmptyHandling() {
        assertFalse(PasswordUtil.verifyPassword(null, "somehash"), "Null password should return false");
        assertFalse(PasswordUtil.verifyPassword("password", null), "Null hash should return false");
        assertFalse(PasswordUtil.verifyPassword(null, null), "Both null should return false");
        assertFalse(PasswordUtil.verifyPassword("", "hash"), "Empty password should return false");
    }
    
    @Test
    @DisplayName("Test Constant-Time Comparison (Timing Attack Prevention)")
    public void testConstantTimeComparison() {
        String password = "TestPassword";
        String hash = PasswordUtil.hashPassword(password);
        
        // Measure time for correct password
        long start1 = System.nanoTime();
        PasswordUtil.verifyPassword(password, hash);
        long time1 = System.nanoTime() - start1;
        
        // Measure time for wrong password (first char different)
        long start2 = System.nanoTime();
        PasswordUtil.verifyPassword("XestPassword", hash);
        long time2 = System.nanoTime() - start2;
        
        // Times should be similar (within 50% variance due to system noise)
        double ratio = (double) Math.max(time1, time2) / Math.min(time1, time2);
        assertTrue(ratio < 2.0, "Verification time should be constant (timing attack prevention)");
    }
    
    @Test
    @DisplayName("Test Security Against Rainbow Table Attack")
    public void testRainbowTableResistance() {
        // Common passwords
        String[] commonPasswords = {"password", "123456", "admin", "test"};
        
        for (String password : commonPasswords) {
            String hash = PasswordUtil.hashPassword(password);
            
            // Hash should not match known SHA-256 rainbow table values
            assertNotEquals(64, hash.length(), "Hash should not be simple SHA-256 (64 hex chars)");
            assertTrue(hash.contains(":"), "Hash should include salt");
            
            // Each hash of same password should be different
            String hash2 = PasswordUtil.hashPassword(password);
            assertNotEquals(hash, hash2, "Same password should produce different hashes");
        }
    }
    
    @Test
    @DisplayName("Test PBKDF2 Iteration Count")
    public void testPBKDF2Iterations() {
        // Hash a password and measure time
        long start = System.nanoTime();
        String hash = PasswordUtil.hashPassword("TestPassword");
        long duration = System.nanoTime() - start;
        
        // PBKDF2 with 65536 iterations should take at least 10ms
        // (prevents brute force by making hashing expensive)
        assertTrue(duration > 10_000_000, // 10ms in nanoseconds
            "PBKDF2 should take significant time (proves high iteration count)");
        
        System.out.println("Hash generation time: " + (duration / 1_000_000) + "ms");
    }
    
    @Test
    @DisplayName("Test Case Sensitivity")
    public void testCaseSensitivity() {
        String password = "TestPassword123";
        String hash = PasswordUtil.hashPassword(password);
        
        assertTrue(PasswordUtil.verifyPassword("TestPassword123", hash));
        assertFalse(PasswordUtil.verifyPassword("testpassword123", hash), "Password should be case-sensitive");
        assertFalse(PasswordUtil.verifyPassword("TESTPASSWORD123", hash), "Password should be case-sensitive");
    }
    
    @Test
    @DisplayName("Test Special Characters in Password")
    public void testSpecialCharacters() {
        String password = "P@ssw0rd!#$%";
        String hash = PasswordUtil.hashPassword(password);
        
        assertTrue(PasswordUtil.verifyPassword(password, hash), "Special characters should be supported");
        assertFalse(PasswordUtil.verifyPassword("P@ssw0rd", hash), "Missing special chars should fail");
    }
    
    @Test
    @DisplayName("Test Unicode Characters in Password")
    public void testUnicodeCharacters() {
        String password = "Pass™ωθrd🔐";
        String hash = PasswordUtil.hashPassword(password);
        
        assertTrue(PasswordUtil.verifyPassword(password, hash), "Unicode characters should be supported");
    }
    
    @Test
    @DisplayName("Test Hash Consistency")
    public void testHashConsistency() {
        String password = "ConsistentPassword";
        String hash = PasswordUtil.hashPassword(password);
        
        // Verify multiple times - should always work
        for (int i = 0; i < 100; i++) {
            assertTrue(PasswordUtil.verifyPassword(password, hash), 
                "Hash verification should be consistent (iteration " + i + ")");
        }
    }
    
    @Test
    @DisplayName("Performance Test - Batch Hashing")
    @Disabled("Enable for performance testing only")
    public void performanceTestBatchHashing() {
        int iterations = 1000;
        long start = System.nanoTime();
        
        for (int i = 0; i < iterations; i++) {
            PasswordUtil.hashPassword("Password" + i);
        }
        
        long duration = System.nanoTime() - start;
        long avgTime = duration / iterations / 1_000_000; // ms per hash
        
        System.out.println("Average hash time: " + avgTime + "ms");
        
        // Should be between 10-100ms per hash (indicates proper iteration count)
        assertTrue(avgTime >= 10 && avgTime <= 100, 
            "Hash time should indicate proper PBKDF2 iteration count");
    }
}
