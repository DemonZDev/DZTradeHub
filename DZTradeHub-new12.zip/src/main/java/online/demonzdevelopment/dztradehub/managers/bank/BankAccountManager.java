package online.demonzdevelopment.dztradehub.managers.bank;

import online.demonzdevelopment.dzeconomy.currency.CurrencyType;
import online.demonzdevelopment.dztradehub.DZTradeHub;
import online.demonzdevelopment.dztradehub.data.bank.*;
import online.demonzdevelopment.dztradehub.utils.PasswordUtil;
import org.bukkit.entity.Player;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class BankAccountManager {
    private final DZTradeHub plugin;
    private final BankManager bankManager;
    private final Map<UUID, BankAccount> accountsById;
    private final Map<UUID, List<BankAccount>> accountsByPlayer; // player UUID -> accounts
    
    public BankAccountManager(DZTradeHub plugin, BankManager bankManager) {
        this.plugin = plugin;
        this.bankManager = bankManager;
        this.accountsById = new ConcurrentHashMap<>();
        this.accountsByPlayer = new ConcurrentHashMap<>();
        
        loadAccountsFromDatabase();
    }
    
    /**
     * Load all accounts from database
     */
    private void loadAccountsFromDatabase() {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "SELECT * FROM bank_accounts WHERE active = 1";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                BankAccount account = loadAccountFromResultSet(rs);
                if (account != null) {
                    registerAccount(account);
                }
            }
            
            plugin.getLogger().info("Loaded " + accountsById.size() + " bank accounts");
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to load bank accounts: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Load account from ResultSet
     */
    private BankAccount loadAccountFromResultSet(ResultSet rs) throws SQLException {
        UUID accountId = UUID.fromString(rs.getString("account_id"));
        UUID bankId = UUID.fromString(rs.getString("bank_id"));
        UUID playerUUID = UUID.fromString(rs.getString("player_uuid"));
        String playerName = rs.getString("player_name");
        
        BankAccount account = new BankAccount(accountId, bankId, playerUUID, playerName);
        
        try {
            account.setAccountType(AccountType.valueOf(rs.getString("account_type")));
        } catch (IllegalArgumentException e) {
            account.setAccountType(AccountType.SAVINGS);
        }
        
        account.setPasswordHash(rs.getString("password_hash"));
        account.setAccountLevel(rs.getInt("account_level"));
        account.setBalance(CurrencyType.MONEY, rs.getDouble("money_balance"));
        account.setBalance(CurrencyType.MOBCOIN, rs.getDouble("mobcoin_balance"));
        account.setBalance(CurrencyType.GEM, rs.getDouble("gem_balance"));
        account.setCreatedTime(rs.getLong("created_time"));
        account.setLastAccessTime(rs.getLong("last_access_time"));
        account.setTotalTransactions(rs.getInt("total_transactions"));
        account.setTotalInterestEarned(rs.getLong("total_interest_earned"));
        account.setActive(rs.getInt("active") == 1);
        account.setLocked(rs.getInt("locked") == 1);
        
        return account;
    }
    
    /**
     * Create a new bank account
     */
    public BankAccount createAccount(UUID playerUUID, String playerName, Bank bank, AccountType accountType, String password) {
        // Validate password
        if (!PasswordUtil.isPasswordValid(password)) {
            return null;
        }
        
        // Check if player already has account at this bank
        if (hasAccountAtBank(playerUUID, bank.getBankId())) {
            return null;
        }
        
        // Check max accounts limit
        if (getPlayerAccountCount(playerUUID) >= bankManager.getConfigManager().getMaxAccountsPerPlayer()) {
            return null;
        }
        
        // Check if account type is available
        if (!bank.isAccountTypeAvailable(accountType)) {
            return null;
        }
        
        // Hash password
        String passwordHash = PasswordUtil.hashPassword(password);
        
        // Create account
        BankAccount account = new BankAccount(bank.getBankId(), playerUUID, playerName, accountType, passwordHash);
        
        // Save to database
        if (saveAccountToDatabase(account)) {
            registerAccount(account);
            return account;
        }
        
        return null;
    }
    
    /**
     * Save account to database
     */
    private boolean saveAccountToDatabase(BankAccount account) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "INSERT INTO bank_accounts (account_id, bank_id, player_uuid, player_name, " +
                        "account_type, password_hash, account_level, money_balance, mobcoin_balance, " +
                        "gem_balance, created_time, last_access_time, total_transactions, " +
                        "total_interest_earned, active, locked) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, account.getAccountId().toString());
            stmt.setString(2, account.getBankId().toString());
            stmt.setString(3, account.getPlayerUUID().toString());
            stmt.setString(4, account.getPlayerName());
            stmt.setString(5, account.getAccountType().name());
            stmt.setString(6, account.getPasswordHash());
            stmt.setInt(7, account.getAccountLevel());
            stmt.setDouble(8, account.getBalance(CurrencyType.MONEY));
            stmt.setDouble(9, account.getBalance(CurrencyType.MOBCOIN));
            stmt.setDouble(10, account.getBalance(CurrencyType.GEM));
            stmt.setLong(11, account.getCreatedTime());
            stmt.setLong(12, account.getLastAccessTime());
            stmt.setInt(13, account.getTotalTransactions());
            stmt.setLong(14, account.getTotalInterestEarned());
            stmt.setInt(15, account.isActive() ? 1 : 0);
            stmt.setInt(16, account.isLocked() ? 1 : 0);
            
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to save bank account: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Update account in database
     */
    public void updateAccount(BankAccount account) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection conn = plugin.getDatabaseManager().getConnection()) {
                String sql = "UPDATE bank_accounts SET account_type = ?, account_level = ?, " +
                            "money_balance = ?, mobcoin_balance = ?, gem_balance = ?, " +
                            "last_access_time = ?, total_transactions = ?, total_interest_earned = ?, " +
                            "locked = ? WHERE account_id = ?";
                
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, account.getAccountType().name());
                stmt.setInt(2, account.getAccountLevel());
                stmt.setDouble(3, account.getBalance(CurrencyType.MONEY));
                stmt.setDouble(4, account.getBalance(CurrencyType.MOBCOIN));
                stmt.setDouble(5, account.getBalance(CurrencyType.GEM));
                stmt.setLong(6, account.getLastAccessTime());
                stmt.setInt(7, account.getTotalTransactions());
                stmt.setLong(8, account.getTotalInterestEarned());
                stmt.setInt(9, account.isLocked() ? 1 : 0);
                stmt.setString(10, account.getAccountId().toString());
                
                stmt.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to update bank account: " + e.getMessage());
            }
        });
    }
    
    /**
     * Delete account
     */
    public boolean deleteAccount(UUID accountId) {
        BankAccount account = getAccountById(accountId);
        if (account == null) {
            return false;
        }
        
        // Check for active loans
        // TODO: Check if account has active loans
        
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "UPDATE bank_accounts SET active = 0 WHERE account_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, accountId.toString());
            stmt.executeUpdate();
            
            unregisterAccount(account);
            return true;
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to delete account: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Verify password (with account object)
     */
    public boolean verifyPassword(BankAccount account, String password) {
        if (account == null) {
            return false;
        }
        return PasswordUtil.verifyPassword(password, account.getPasswordHash());
    }
    
    /**
     * Verify password (with account ID)
     */
    public boolean verifyPassword(UUID accountId, String password) {
        BankAccount account = getAccountById(accountId);
        if (account == null) {
            return false;
        }
        return PasswordUtil.verifyPassword(password, account.getPasswordHash());
    }
    
    /**
     * Save account (sync)
     */
    public void saveAccount(BankAccount account) {
        updateAccount(account);
    }
    
    /**
     * Record a transaction
     */
    public void recordTransaction(BankAccount account, CurrencyType currency, double amount, 
                                 double afterTax, BankTransactionType type) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection conn = plugin.getDatabaseManager().getConnection()) {
                String sql = "INSERT INTO bank_transactions (transaction_id, account_id, " +
                            "transaction_type, currency_type, amount, after_tax, timestamp) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?)";
                
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, UUID.randomUUID().toString());
                stmt.setString(2, account.getAccountId().toString());
                stmt.setString(3, type.name());
                stmt.setString(4, currency.name());
                stmt.setDouble(5, amount);
                stmt.setDouble(6, afterTax);
                stmt.setLong(7, System.currentTimeMillis());
                
                stmt.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to record transaction: " + e.getMessage());
            }
        });
    }
    
    /**
     * Change password
     */
    public boolean changePassword(UUID accountId, String oldPassword, String newPassword) {
        if (!verifyPassword(accountId, oldPassword)) {
            return false;
        }
        
        if (!PasswordUtil.isPasswordValid(newPassword)) {
            return false;
        }
        
        BankAccount account = getAccountById(accountId);
        if (account == null) {
            return false;
        }
        
        String newHash = PasswordUtil.hashPassword(newPassword);
        account.setPasswordHash(newHash);
        
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "UPDATE bank_accounts SET password_hash = ? WHERE account_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, newHash);
            stmt.setString(2, accountId.toString());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to change password: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Deposit currency from player wallet to bank account
     */
    public boolean deposit(Player player, BankAccount account, CurrencyType currency, double amount) {
        Bank bank = bankManager.getBankById(account.getBankId());
        if (bank == null) {
            return false;
        }
        
        // Check if currency is enabled
        if (!bank.isCurrencyEnabled(currency)) {
            player.sendMessage("§c" + currency.name() + " is not accepted by this bank!");
            return false;
        }
        
        // Check player balance
        double playerBalance = plugin.getEconomyAPI().getBalance(player.getUniqueId(), currency);
        if (playerBalance < amount) {
            player.sendMessage("§cYou don't have enough " + currency.name() + "!");
            return false;
        }
        
        // Calculate tax
        double taxRate = calculateDepositTax(bank, account);
        double taxAmount = amount * (taxRate / 100.0);
        double netAmount = amount - taxAmount;
        
        // Check max storage
        double maxStorage = getMaxStorage(bank, account, currency);
        double currentBalance = account.getBalance(currency);
        if (currentBalance + netAmount > maxStorage) {
            player.sendMessage("§cThis would exceed your maximum storage limit!");
            player.sendMessage("§cMax: " + maxStorage + " | Current: " + currentBalance);
            return false;
        }
        
        // Check wallet balance
        double walletBalance = plugin.getEconomyAPI().getBalance(player.getUniqueId(), currency);
        if (walletBalance < amount) {
            player.sendMessage("§cInsufficient funds in your wallet!");
            return false;
        }
        
        // Deduct from wallet
        plugin.getEconomyAPI().removeCurrency(player.getUniqueId(), currency, amount);
        
        // Add to bank account
        double balanceBefore = account.getBalance(currency);
        account.addBalance(currency, netAmount);
        account.incrementTransactions();
        account.updateAccessTime();
        
        // Save
        updateAccount(account);
        
        // Record transaction
        recordTransaction(account, BankTransactionType.DEPOSIT, currency, netAmount, balanceBefore, account.getBalance(currency));
        if (taxAmount > 0) {
            recordTransaction(account, BankTransactionType.TAX_DEDUCTED, currency, taxAmount, 0, 0);
        }
        
        // Notify player
        player.sendMessage("§a✓ Deposited " + String.format("%.2f", amount) + " " + currency.name());
        if (taxAmount > 0) {
            player.sendMessage("§7Tax: " + String.format("%.2f", taxAmount) + " (" + String.format("%.1f", taxRate) + "%)");
        }
        player.sendMessage("§7New balance: " + String.format("%.2f", account.getBalance(currency)) + " " + currency.name());
        
        return true;
    }
    
    /**
     * Withdraw currency from bank account to player wallet
     */
    public boolean withdraw(Player player, BankAccount account, CurrencyType currency, double amount) {
        Bank bank = bankManager.getBankById(account.getBankId());
        if (bank == null) {
            return false;
        }
        
        // Check if currency is enabled
        if (!bank.isCurrencyEnabled(currency)) {
            player.sendMessage("§c" + currency.name() + " is not accepted by this bank!");
            return false;
        }
        
        // Calculate tax
        double taxRate = calculateWithdrawalTax(bank, account);
        double totalNeeded = amount * (1 + taxRate / 100.0);
        
        // Check bank balance
        if (!account.hasBalance(currency, totalNeeded)) {
            player.sendMessage("§cInsufficient bank balance!");
            player.sendMessage("§cRequired: " + String.format("%.2f", totalNeeded) + " (including tax)");
            player.sendMessage("§cBalance: " + String.format("%.2f", account.getBalance(currency)));
            return false;
        }
        
        // Deduct from bank account
        double balanceBefore = account.getBalance(currency);
        account.deductBalance(currency, totalNeeded);
        account.incrementTransactions();
        account.updateAccessTime();
        
        // Add to wallet
        plugin.getEconomyAPI().addCurrency(player.getUniqueId(), currency, amount);
        
        // Save
        updateAccount(account);
        
        // Record transaction
        double taxAmount = totalNeeded - amount;
        recordTransaction(account, BankTransactionType.WITHDRAWAL, currency, amount, balanceBefore, account.getBalance(currency));
        if (taxAmount > 0) {
            recordTransaction(account, BankTransactionType.TAX_DEDUCTED, currency, taxAmount, 0, 0);
        }
        
        // Notify player
        player.sendMessage("§a✓ Withdrew " + String.format("%.2f", amount) + " " + currency.name());
        if (taxAmount > 0) {
            player.sendMessage("§7Tax: " + String.format("%.2f", taxAmount) + " (" + String.format("%.1f", taxRate) + "%)");
        }
        player.sendMessage("§7New balance: " + String.format("%.2f", account.getBalance(currency)) + " " + currency.name());
        
        return true;
    }
    
    /**
     * Calculate deposit tax rate for account
     */
    private double calculateDepositTax(Bank bank, BankAccount account) {
        double baseTax = bank.getGlobalDepositTax();
        double multiplier = account.getAccountType().getDepositTaxMultiplier();
        double levelReduction = 0;
        
        BankLevelConfig levelConfig = bank.getLevelConfig(account.getAccountLevel());
        if (levelConfig != null) {
            levelReduction = levelConfig.getDepositTaxReduction();
        }
        
        double finalTax = baseTax * multiplier;
        finalTax -= (finalTax * (levelReduction / 100.0));
        return Math.max(0, finalTax);
    }
    
    /**
     * Calculate withdrawal tax rate for account
     */
    private double calculateWithdrawalTax(Bank bank, BankAccount account) {
        double baseTax = bank.getGlobalWithdrawalTax();
        double multiplier = account.getAccountType().getWithdrawalTaxMultiplier();
        double levelReduction = 0;
        
        BankLevelConfig levelConfig = bank.getLevelConfig(account.getAccountLevel());
        if (levelConfig != null) {
            levelReduction = levelConfig.getWithdrawalTaxReduction();
        }
        
        double finalTax = baseTax * multiplier;
        finalTax -= (finalTax * (levelReduction / 100.0));
        return Math.max(0, finalTax);
    }
    
    /**
     * Get max storage for account
     */
    private double getMaxStorage(Bank bank, BankAccount account, CurrencyType currency) {
        double baseMax = bank.getMaxStorage(currency);
        BankLevelConfig levelConfig = bank.getLevelConfig(account.getAccountLevel());
        if (levelConfig != null) {
            baseMax += levelConfig.getMaxBalanceIncrease(currency);
        }
        return baseMax;
    }
    
    /**
     * Record transaction
     */
    private void recordTransaction(BankAccount account, BankTransactionType type, CurrencyType currency, 
                                   double amount, double balanceBefore, double balanceAfter) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection conn = plugin.getDatabaseManager().getConnection()) {
                String sql = "INSERT INTO bank_transactions (transaction_id, account_id, bank_id, " +
                            "player_uuid, transaction_type, currency, amount, balance_before, " +
                            "balance_after, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, UUID.randomUUID().toString());
                stmt.setString(2, account.getAccountId().toString());
                stmt.setString(3, account.getBankId().toString());
                stmt.setString(4, account.getPlayerUUID().toString());
                stmt.setString(5, type.name());
                stmt.setString(6, currency.name());
                stmt.setDouble(7, amount);
                stmt.setDouble(8, balanceBefore);
                stmt.setDouble(9, balanceAfter);
                stmt.setLong(10, System.currentTimeMillis());
                
                stmt.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to record transaction: " + e.getMessage());
            }
        });
    }
    
    /**
     * Register account in memory
     */
    private void registerAccount(BankAccount account) {
        accountsById.put(account.getAccountId(), account);
        accountsByPlayer.computeIfAbsent(account.getPlayerUUID(), k -> new ArrayList<>()).add(account);
    }
    
    /**
     * Unregister account from memory
     */
    private void unregisterAccount(BankAccount account) {
        accountsById.remove(account.getAccountId());
        List<BankAccount> playerAccounts = accountsByPlayer.get(account.getPlayerUUID());
        if (playerAccounts != null) {
            playerAccounts.remove(account);
        }
    }
    
    // Getters and utility methods
    public BankAccount getAccountById(UUID accountId) {
        return accountsById.get(accountId);
    }
    
    public List<BankAccount> getPlayerAccounts(UUID playerUUID) {
        return accountsByPlayer.getOrDefault(playerUUID, new ArrayList<>());
    }
    
    public BankAccount getPlayerAccountAtBank(UUID playerUUID, UUID bankId) {
        List<BankAccount> accounts = getPlayerAccounts(playerUUID);
        return accounts.stream()
            .filter(acc -> acc.getBankId().equals(bankId))
            .findFirst()
            .orElse(null);
    }
    
    public boolean hasAccountAtBank(UUID playerUUID, UUID bankId) {
        return getPlayerAccountAtBank(playerUUID, bankId) != null;
    }
    
    public int getPlayerAccountCount(UUID playerUUID) {
        return getPlayerAccounts(playerUUID).size();
    }
}
