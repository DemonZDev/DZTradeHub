package online.demonzdevelopment.utils;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;

public class MessageUtil {
    private static final String PREFIX = "<gold>[TradeHub]</gold> ";
    private static final MiniMessage miniMessage = MiniMessage.miniMessage();

    public static void send(Player player, String message) {
        Component component = miniMessage.deserialize(PREFIX + message);
        player.sendMessage(component);
    }

    public static void sendError(Player player, String message) {
        send(player, "<red>" + message + "</red>");
    }

    public static void sendSuccess(Player player, String message) {
        send(player, "<green>" + message + "</green>");
    }

    public static void sendInfo(Player player, String message) {
        send(player, "<yellow>" + message + "</yellow>");
    }

    public static Component parseComponent(String text) {
        return miniMessage.deserialize(text);
    }

    public static String stripFormatting(String text) {
        return text.replaceAll("§[0-9a-fk-or]", "");
    }
}