package online.demonzdevelopment.api;

public enum CurrencyType {
    MONEY, MOBCOIN, GEM
}