package online.demonzdevelopment.api;

import java.util.UUID;

/**
 * DZEconomy API Interface
 * This interface defines the contract for the DZEconomy plugin API
 */
public interface DZEconomyAPI {
    
    /**
     * Check if a player has sufficient balance
     * @param playerUUID The player's UUID
     * @param currencyType The type of currency
     * @param amount The amount to check
     * @return true if the player has the balance, false otherwise
     */
    boolean hasBalance(UUID playerUUID, CurrencyType currencyType, double amount);
    
    /**
     * Get a player's balance
     * @param playerUUID The player's UUID
     * @param currencyType The type of currency
     * @return The player's balance
     */
    double getBalance(UUID playerUUID, CurrencyType currencyType);
    
    /**
     * Add currency to a player's balance
     * @param playerUUID The player's UUID
     * @param currencyType The type of currency
     * @param amount The amount to add
     */
    void addCurrency(UUID playerUUID, CurrencyType currencyType, double amount);
    
    /**
     * Remove currency from a player's balance
     * @param playerUUID The player's UUID
     * @param currencyType The type of currency
     * @param amount The amount to remove
     */
    void removeCurrency(UUID playerUUID, CurrencyType currencyType, double amount);
    
    /**
     * Transfer currency between players
     * @param fromUUID The sender's UUID
     * @param toUUID The receiver's UUID
     * @param currencyType The type of currency
     * @param amount The amount to transfer
     * @return true if successful, false otherwise
     */
    boolean transferCurrency(UUID fromUUID, UUID toUUID, CurrencyType currencyType, double amount);
    
    /**
     * Convert one currency type to another
     * @param playerUUID The player's UUID
     * @param fromType The source currency type
     * @param toType The target currency type
     * @param amount The amount to convert
     * @return true if successful, false otherwise
     */
    boolean convertCurrency(UUID playerUUID, CurrencyType fromType, CurrencyType toType, double amount);
    
    /**
     * Format a currency amount for display
     * @param amount The amount to format
     * @param currencyType The type of currency
     * @return Formatted string (e.g., "$1.5K", "$250", "$2.3M")
     */
    String formatCurrency(double amount, CurrencyType currencyType);
    
    /**
     * Get a player's rank
     * @param playerUUID The player's UUID
     * @return The player's rank data
     */
    Rank getPlayerRank(UUID playerUUID);
    
    /**
     * Rank interface for compatibility
     */
    interface Rank {
        String getDisplayName();
        int getPriority();
        RankCurrencySettings getMoneySettings();
    }
    
    /**
     * Rank currency settings interface
     */
    interface RankCurrencySettings {
        double getTransferTax();
        double getDailyTransferLimit();
        long getTransferCooldown();
    }
}
