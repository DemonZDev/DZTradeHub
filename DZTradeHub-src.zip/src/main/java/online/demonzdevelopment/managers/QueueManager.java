package online.demonzdevelopment.managers;

import online.demonzdevelopment.DZTradeHub;
import online.demonzdevelopment.data.Shop;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class QueueManager {
    private final DZTradeHub plugin;
    private final Map<UUID, Queue<QueueEntry>> shopQueues; // shopId -> queue
    private final Map<UUID, UUID> currentShoppers; // playerId -> shopId
    private final Map<UUID, Long> lastActivityTime; // playerId -> timestamp

    public record QueueEntry(UUID playerUUID, int priority, long joinTime) implements Comparable<QueueEntry> {
        @Override
        public int compareTo(QueueEntry other) {
            // Higher priority first, then earlier join time
            if (this.priority != other.priority) {
                return Integer.compare(other.priority, this.priority);
            }
            return Long.compare(this.joinTime, other.joinTime);
        }
    }

    public QueueManager(DZTradeHub plugin) {
        this.plugin = plugin;
        this.shopQueues = new ConcurrentHashMap<>();
        this.currentShoppers = new ConcurrentHashMap<>();
        this.lastActivityTime = new ConcurrentHashMap<>();
        
        // Start AFK checker
        startAFKChecker();
    }

    public void joinQueue(Player player, Shop shop, int priority) {
        UUID shopId = shop.getId();
        Queue<QueueEntry> queue = shopQueues.computeIfAbsent(shopId, k -> new PriorityQueue<>());
        
        // Check if player is already in queue
        if (isInQueue(player, shop)) {
            player.sendMessage("§cYou are already in this shop's queue!");
            return;
        }
        
        // Check if shop is empty
        if (!currentShoppers.containsValue(shopId)) {
            // Shop is empty, let player enter directly
            enterShop(player, shop);
            return;
        }
        
        // Add to queue
        queue.add(new QueueEntry(player.getUniqueId(), priority, System.currentTimeMillis()));
        int position = getQueuePosition(player, shop);
        player.sendMessage("§eYou joined the queue at position §b#" + position);
    }

    public void leaveQueue(Player player, Shop shop) {
        Queue<QueueEntry> queue = shopQueues.get(shop.getId());
        if (queue != null) {
            queue.removeIf(entry -> entry.playerUUID().equals(player.getUniqueId()));
            player.sendMessage("§7You left the queue.");
        }
    }

    public void enterShop(Player player, Shop shop) {
        currentShoppers.put(player.getUniqueId(), shop.getId());
        lastActivityTime.put(player.getUniqueId(), System.currentTimeMillis());
        player.sendMessage("§aIt's your turn! Opening shop...");
        
        // Open shop GUI (will be handled by GUI class)
        plugin.getShopGUI().openShop(player, shop);
    }

    public void exitShop(Player player) {
        UUID shopId = currentShoppers.remove(player.getUniqueId());
        lastActivityTime.remove(player.getUniqueId());
        
        if (shopId != null) {
            // Get next player in queue
            Queue<QueueEntry> queue = shopQueues.get(shopId);
            if (queue != null && !queue.isEmpty()) {
                QueueEntry next = queue.poll();
                Player nextPlayer = plugin.getServer().getPlayer(next.playerUUID());
                if (nextPlayer != null && nextPlayer.isOnline()) {
                    Shop shop = getShopById(shopId);
                    if (shop != null) {
                        enterShop(nextPlayer, shop);
                    }
                } else {
                    // Player left, try next
                    exitShop(player);
                }
            }
        }
    }

    public boolean isInQueue(Player player, Shop shop) {
        Queue<QueueEntry> queue = shopQueues.get(shop.getId());
        if (queue == null) return false;
        return queue.stream().anyMatch(entry -> entry.playerUUID().equals(player.getUniqueId()));
    }

    public int getQueuePosition(Player player, Shop shop) {
        Queue<QueueEntry> queue = shopQueues.get(shop.getId());
        if (queue == null) return -1;
        
        List<QueueEntry> list = new ArrayList<>(queue);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).playerUUID().equals(player.getUniqueId())) {
                return i + 1;
            }
        }
        return -1;
    }

    public boolean isShoppingAt(Player player, Shop shop) {
        UUID shopId = currentShoppers.get(player.getUniqueId());
        return shopId != null && shopId.equals(shop.getId());
    }

    public void updateActivity(Player player) {
        lastActivityTime.put(player.getUniqueId(), System.currentTimeMillis());
    }

    private void startAFKChecker() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            long now = System.currentTimeMillis();
            List<UUID> toKick = new ArrayList<>();
            
            currentShoppers.forEach((playerUUID, shopId) -> {
                Long lastActivity = lastActivityTime.get(playerUUID);
                if (lastActivity != null) {
                    long elapsed = now - lastActivity;
                    Shop shop = getShopById(shopId);
                    if (shop != null && elapsed > (shop.getAfkKickTime() * 1000L)) {
                        toKick.add(playerUUID);
                    }
                }
            });
            
            toKick.forEach(playerUUID -> {
                Player player = plugin.getServer().getPlayer(playerUUID);
                if (player != null) {
                    player.sendMessage("§cKicked from shop due to inactivity.");
                    player.closeInventory();
                    exitShop(player);
                }
            });
        }, 20L, 20L); // Run every second
    }

    private Shop getShopById(UUID shopId) {
        for (String areaName : plugin.getShopManager().getAllAreas().stream()
                .map(area -> area.getName()).toList()) {
            for (Shop shop : plugin.getShopManager().getShopsInArea(areaName)) {
                if (shop.getId().equals(shopId)) {
                    return shop;
                }
            }
        }
        return null;
    }
}