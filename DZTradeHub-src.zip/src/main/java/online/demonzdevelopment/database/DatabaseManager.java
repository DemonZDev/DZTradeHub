package online.demonzdevelopment.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import online.demonzdevelopment.DZTradeHub;
import online.demonzdevelopment.data.*;
import online.demonzdevelopment.utils.ConfigManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.sql.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;

public class DatabaseManager {
    private final DZTradeHub plugin;
    private HikariDataSource dataSource;
    private final String databaseType;

    public DatabaseManager(DZTradeHub plugin) {
        this.plugin = plugin;
        ConfigManager configManager = plugin.getConfigManager();
        this.databaseType = configManager.getDatabaseType();
        
        setupDatabase();
        createTables();
    }

    private void setupDatabase() {
        HikariConfig config = new HikariConfig();
        
        if (databaseType.equalsIgnoreCase("MYSQL")) {
            ConfigManager cm = plugin.getConfigManager();
            config.setJdbcUrl(String.format("jdbc:mysql://%s:%d/%s",
                cm.getMySQLHost(), cm.getMySQLPort(), cm.getMySQLDatabase()));
            config.setUsername(cm.getMySQLUsername());
            config.setPassword(cm.getMySQLPassword());
            config.addDataSourceProperty("cachePrepStmts", "true");
            config.addDataSourceProperty("prepStmtCacheSize", "250");
            config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        } else {
            // SQLite
            File dataFolder = plugin.getDataFolder();
            if (!dataFolder.exists()) {
                dataFolder.mkdirs();
            }
            config.setJdbcUrl("jdbc:sqlite:" + new File(dataFolder, "database.db").getAbsolutePath());
            config.setDriverClassName("org.sqlite.JDBC");
        }
        
        config.setMaximumPoolSize(10);
        config.setMinimumIdle(2);
        config.setConnectionTimeout(30000);
        config.setPoolName("DZTradeHub-Pool");
        
        dataSource = new HikariDataSource(config);
    }

    private void createTables() {
        try (Connection conn = getConnection()) {
            // Shops table
            conn.createStatement().execute(
                "CREATE TABLE IF NOT EXISTS shops (" +
                "id VARCHAR(36) PRIMARY KEY, " +
                "area_name VARCHAR(100) NOT NULL, " +
                "shop_name VARCHAR(100) NOT NULL, " +
                "display_name VARCHAR(200), " +
                "shop_type VARCHAR(20), " +
                "data TEXT, " +
                "UNIQUE(area_name, shop_name))" 
            );

            // Shop items table
            conn.createStatement().execute(
                "CREATE TABLE IF NOT EXISTS shop_items (" +
                "id VARCHAR(36) PRIMARY KEY, " +
                "shop_id VARCHAR(36), " +
                "item_data BLOB, " +
                "buy_price REAL, " +
                "sell_price REAL, " +
                "current_stock INTEGER, " +
                "max_stock INTEGER, " +
                "refill_interval VARCHAR(20), " +
                "refill_amount INTEGER, " +
                "min_price REAL, " +
                "max_price REAL, " +
                "dynamic_pricing INTEGER, " +
                "transaction_type VARCHAR(20), " +
                "FOREIGN KEY(shop_id) REFERENCES shops(id) ON DELETE CASCADE)" 
            );

            // Transactions table
            conn.createStatement().execute(
                "CREATE TABLE IF NOT EXISTS transactions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "player_uuid VARCHAR(36), " +
                "shop_id VARCHAR(36), " +
                "item_type VARCHAR(50), " +
                "quantity INTEGER, " +
                "price_per_item REAL, " +
                "total_price REAL, " +
                "transaction_type VARCHAR(10), " +
                "currency_type VARCHAR(20), " +
                "timestamp BIGINT)" 
            );

            // Auctions table
            conn.createStatement().execute(
                "CREATE TABLE IF NOT EXISTS auctions (" +
                "id VARCHAR(36) PRIMARY KEY, " +
                "seller_uuid VARCHAR(36), " +
                "item_data BLOB, " +
                "actual_price REAL, " +
                "max_drop_price REAL, " +
                "drop_per_unit REAL, " +
                "drop_interval_hours INTEGER, " +
                "max_queue INTEGER, " +
                "price_increase_percent REAL, " +
                "created_time BIGINT, " +
                "last_drop_time BIGINT, " +
                "frozen INTEGER, " +
                "queue_data TEXT)" 
            );

            // Kit cooldowns table
            conn.createStatement().execute(
                "CREATE TABLE IF NOT EXISTS kit_cooldowns (" +
                "player_uuid VARCHAR(36), " +
                "kit_name VARCHAR(100), " +
                "last_claim BIGINT, " +
                "PRIMARY KEY(player_uuid, kit_name))" 
            );

            // Player carts table
            conn.createStatement().execute(
                "CREATE TABLE IF NOT EXISTS player_carts (" +
                "player_uuid VARCHAR(36), " +
                "shop_id VARCHAR(36), " +
                "cart_data TEXT, " +
                "last_updated BIGINT, " +
                "PRIMARY KEY(player_uuid, shop_id))" 
            );

            plugin.getLogger().info("Database tables created successfully");
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to create database tables: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    // Async operations
    public CompletableFuture<Void> saveShopAsync(Shop shop, String areaName) {
        return CompletableFuture.runAsync(() -> {
            try (Connection conn = getConnection()) {
                String sql = "INSERT OR REPLACE INTO shops (id, area_name, shop_name, display_name, shop_type) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, shop.getId().toString());
                stmt.setString(2, areaName);
                stmt.setString(3, shop.getName());
                stmt.setString(4, shop.getDisplayName());
                stmt.setString(5, shop.getShopType().name());
                stmt.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to save shop: " + e.getMessage());
            }
        });
    }

    public CompletableFuture<Void> saveShopItemAsync(ShopItem item, UUID shopId) {
        return CompletableFuture.runAsync(() -> {
            try (Connection conn = getConnection()) {
                String sql = "INSERT OR REPLACE INTO shop_items (id, shop_id, item_data, buy_price, sell_price, " +
                    "current_stock, max_stock, refill_interval, refill_amount, min_price, max_price, " +
                    "dynamic_pricing, transaction_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, item.getId().toString());
                stmt.setString(2, shopId.toString());
                stmt.setBytes(3, serializeItemStack(item.getItemStack()));
                stmt.setDouble(4, item.getBuyPrice());
                stmt.setDouble(5, item.getSellPrice());
                stmt.setInt(6, item.getCurrentStock());
                stmt.setInt(7, item.getMaxStock());
                stmt.setString(8, item.getRefillInterval());
                stmt.setInt(9, item.getRefillAmount());
                stmt.setDouble(10, item.getMinPrice());
                stmt.setDouble(11, item.getMaxPrice());
                stmt.setInt(12, item.isDynamicPricingEnabled() ? 1 : 0);
                stmt.setString(13, item.getTransactionType().name());
                stmt.executeUpdate();
            } catch (Exception e) {
                plugin.getLogger().severe("Failed to save shop item: " + e.getMessage());
            }
        });
    }

    public CompletableFuture<Long> getKitCooldownAsync(UUID playerUUID, String kitName) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = getConnection()) {
                String sql = "SELECT last_claim FROM kit_cooldowns WHERE player_uuid = ? AND kit_name = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, playerUUID.toString());
                stmt.setString(2, kitName);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return rs.getLong("last_claim");
                }
                return 0L;
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to get kit cooldown: " + e.getMessage());
                return 0L;
            }
        });
    }

    public CompletableFuture<Void> setKitCooldownAsync(UUID playerUUID, String kitName, long timestamp) {
        return CompletableFuture.runAsync(() -> {
            try (Connection conn = getConnection()) {
                String sql = "INSERT OR REPLACE INTO kit_cooldowns (player_uuid, kit_name, last_claim) VALUES (?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, playerUUID.toString());
                stmt.setString(2, kitName);
                stmt.setLong(3, timestamp);
                stmt.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to set kit cooldown: " + e.getMessage());
            }
        });
    }

    // Serialize/Deserialize ItemStack
    private byte[] serializeItemStack(ItemStack item) throws Exception {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        BukkitObjectOutputStream dataOutput = new BukkitObjectOutputStream(outputStream);
        dataOutput.writeObject(item);
        dataOutput.close();
        return outputStream.toByteArray();
    }

    private ItemStack deserializeItemStack(byte[] data) throws Exception {
        ByteArrayInputStream inputStream = new ByteArrayInputStream(data);
        BukkitObjectInputStream dataInput = new BukkitObjectInputStream(inputStream);
        ItemStack item = (ItemStack) dataInput.readObject();
        dataInput.close();
        return item;
    }

    public void close() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
            plugin.getLogger().info("Database connection closed");
        }
    }
}