package online.demonzdevelopment.gui;

import net.kyori.adventure.text.Component;
import online.demonzdevelopment.DZTradeHub;
import online.demonzdevelopment.data.Shop;
import online.demonzdevelopment.data.ShopItem;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ShopGUI {
    private final DZTradeHub plugin;

    public static class ShopHolder implements InventoryHolder {
        private final Shop shop;
        private int page;

        public ShopHolder(Shop shop, int page) {
            this.shop = shop;
            this.page = page;
        }

        public Shop getShop() { return shop; }
        public int getPage() { return page; }

        @Override
        public Inventory getInventory() { return null; }
    }

    public ShopGUI(DZTradeHub plugin) {
        this.plugin = plugin;
    }

    public void openShop(Player player, Shop shop) {
        openShop(player, shop, 0);
    }

    public void openShop(Player player, Shop shop, int page) {
        Inventory inv = Bukkit.createInventory(
            new ShopHolder(shop, page),
            54,
            Component.text(shop.getDisplayName())
        );

        // Get items for this page
        List<ShopItem> items = shop.getItems();
        int startIndex = page * 36;
        int endIndex = Math.min(startIndex + 36, items.size());

        // Fill items (slots 9-44)
        for (int i = startIndex; i < endIndex; i++) {
            ShopItem shopItem = items.get(i);
            ItemStack display = createShopItemDisplay(shopItem);
            inv.setItem(9 + (i - startIndex), display);
        }

        // Navigation and control items
        // Previous page (slot 45)
        if (page > 0) {
            ItemStack prev = new ItemStack(Material.ARROW);
            ItemMeta prevMeta = prev.getItemMeta();
            prevMeta.displayName(Component.text("§ePrevious Page"));
            prev.setItemMeta(prevMeta);
            inv.setItem(45, prev);
        }

        // Balance display (slot 47)
        double balance = plugin.getEconomyAPI().getBalance(
            player.getUniqueId(),
            online.demonzdevelopment.api.CurrencyType.MONEY
        );
        ItemStack balanceItem = new ItemStack(Material.GOLD_INGOT);
        ItemMeta balanceMeta = balanceItem.getItemMeta();
        balanceMeta.displayName(Component.text("§eYour Balance"));
        List<Component> balanceLore = new ArrayList<>();
        balanceLore.add(Component.text("§a$" + String.format("%.2f", balance)));
        balanceMeta.lore(balanceLore);
        balanceItem.setItemMeta(balanceMeta);
        inv.setItem(47, balanceItem);

        // Close button (slot 49)
        ItemStack close = new ItemStack(Material.BARRIER);
        ItemMeta closeMeta = close.getItemMeta();
        closeMeta.displayName(Component.text("§cClose"));
        close.setItemMeta(closeMeta);
        inv.setItem(49, close);

        // Next page (slot 53)
        if (endIndex < items.size()) {
            ItemStack next = new ItemStack(Material.ARROW);
            ItemMeta nextMeta = next.getItemMeta();
            nextMeta.displayName(Component.text("§eNext Page"));
            next.setItemMeta(nextMeta);
            inv.setItem(53, next);
        }

        player.openInventory(inv);
    }

    private ItemStack createShopItemDisplay(ShopItem shopItem) {
        ItemStack display = shopItem.getItemStack().clone();
        ItemMeta meta = display.getItemMeta();
        
        List<Component> lore = new ArrayList<>();
        if (meta.hasLore()) {
            lore.addAll(meta.lore());
        }
        
        lore.add(Component.text(""));
        
        if (shopItem.canBuy()) {
            lore.add(Component.text("§7Buy Price: §a$" + String.format("%.2f", shopItem.getBuyPrice())));
            lore.add(Component.text("§7Stock: §e" + shopItem.getCurrentStock() + "/" + shopItem.getMaxStock()));
        }
        
        if (shopItem.canSell()) {
            lore.add(Component.text("§7Sell Price: §e$" + String.format("%.2f", shopItem.getSellPrice())));
        }
        
        lore.add(Component.text(""));
        lore.add(Component.text("§eLeft-click to buy"));
        lore.add(Component.text("§eRight-click to sell"));
        
        meta.lore(lore);
        display.setItemMeta(meta);
        return display;
    }
}