# DZTradeHub - Minecraft Plugin

[![PaperMC](https://img.shields.io/badge/PaperMC-1.21.1-blue)](https://papermc.io/)
[![Java](https://img.shields.io/badge/Java-21-orange)](https://www.oracle.com/java/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

An advanced multi-shop trading system with auction house for PaperMC 1.21.1

## 🎯 Features

### Core Systems
- **Multiple Area Types**
  - Bazar (Small shops with reception queue)
  - SuperMarket (Large stores with checkout system)
  - Junkyard (Instant transactions)
  - PawnShop (Bulk selling)
  - BlackMarket (Exclusive items)
  - Kit System (Rank-based starter kits)
  - Auction House (Player-to-player trading)

### Advanced Queue System
- **Reception Queue**: One player at a time, FIFO with priority
- **Cash Counter Queue**: Multiple simultaneous checkouts
- AFK detection and auto-kick
- Priority-based queue ordering

### Shop Management
- Buy/Sell/Both transaction types
- Dynamic pricing based on supply/demand
- Automatic stock refills
- Stock transfer between shops
- Sale limits (global, area, or per-shop)

### Auction House
- **Price Reduction Auctions**: Decreasing price over time
- **Bidding Queue Auctions**: Queue system with price increases
- Freeze/Resume functionality
- Automatic expiration handling

### Permission System
- Rank-based access control
- Per-area and per-shop permissions
- Cart size limits by rank
- Queue priority by rank
- Auction listing limits

## 📦 Dependencies

- **Required:**
  - PaperMC 1.21.1
  - DZEconomy Plugin
  - Java 21

- **Bundled:**
  - HikariCP 5.1.0
  - SQLite JDBC 3.45.0.0

## 🛠️ Installation

1. Download `DZTradeHub.jar` from [Releases](https://github.com/DemonZDev/DZTradeHub/releases)
2. Place in your server's `plugins` folder
3. Ensure DZEconomy plugin is installed
4. Restart your server
5. Configure files in `plugins/DZTradeHub/`

## 📋 Commands

### Admin Commands (`/dzth`)
```
/dzth set-hand-item <area> <shop> <buy> <sell> - Add item from hand
/dzth set-buy-price <area> <shop> <id> <price> - Set buy price
/dzth set-sell-price <area> <shop> <id> <price> - Set sell price
/dzth add-item - Open item setup GUI
/dzth credit - Show plugin credits
/dzth update - Check for updates
/dzth reload - Reload configurations
```

### Auction Commands (`/ah`)
```
/ah - Open auction browser
/ah add-hand-item <actual> <maxdrop> <drop> <time> <unit> <queue> <increase> - List item
/ah cancel-item <id> - Cancel auction
/ah freeze-item <id> - Freeze auction
/ah un-freeze-item <id> - Resume auction
/ah manage-items - Open management GUI
```

## 🔐 Permissions

```yaml
dztradehub.admin - Full admin access (default: op)
dztradehub.auction - Use auction house (default: true)
dztradehub.rank.default - Default rank access (default: true)
dztradehub.rank.vip - VIP rank access (default: false)
dztradehub.rank.admin - Admin rank access (default: op)
```

## ⚙️ Configuration

### config.yml
Main plugin configuration including database, economy, and queue settings.

### ranks.yml
Define rank permissions, accessible areas/shops, cart sizes, and auction limits.

### kits.yml
Configure starter kits with items, prices, cooldowns, and permissions.

## 🗄️ Database

Supports both SQLite and MySQL:

- **SQLite**: Automatic setup, no configuration needed
- **MySQL**: Configure in `config.yml` under `database.mysql`

### Tables
- `shops` - Shop definitions
- `shop_items` - Items in shops
- `transactions` - Transaction history
- `auctions` - Active auctions
- `kit_cooldowns` - Kit claim cooldowns
- `player_carts` - Shopping carts

## 🔧 Building from Source

```bash
# Clone repository
git clone https://github.com/DemonZDev/DZTradeHub.git
cd DZTradeHub

# Build with Maven
mvn clean package

# Output: target/DZTradeHub.jar
```

## 📚 API Usage

```java
// Get API instance
DZTradeHubAPI api = (DZTradeHubAPI) Bukkit.getServicesManager()
    .getRegistration(DZTradeHubAPI.class)
    .getProvider();

// Get all areas
List<Area> areas = api.getAreas();

// Get a specific shop
Shop shop = api.getShop("Bazar", "MeatShop");

// Add item to shop
ShopItem item = new ShopItem(itemStack, 100.0, 50.0);
api.addItemToShop("Bazar", "MeatShop", item);
```

## 🤝 Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👨‍💻 Developer

**DemonZDev**
- GitHub: [@DemonZDev](https://github.com/DemonZDev)
- Repository: [DZTradeHub](https://github.com/DemonZDev/DZTradeHub)

## 🐛 Bug Reports

Found a bug? Please [open an issue](https://github.com/DemonZDev/DZTradeHub/issues) with:
- Server version
- Plugin version
- Steps to reproduce
- Error logs (if any)

## 💡 Support

For support and questions:
- Open an [issue](https://github.com/DemonZDev/DZTradeHub/issues)
- Check the [wiki](https://github.com/DemonZDev/DZTradeHub/wiki)
- Join our Discord (if available)

---

**Note**: This plugin requires DZEconomy for economy integration. It is not compatible with Vault.
