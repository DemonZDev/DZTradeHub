package online.demonzdevelopment.dztradehub.data;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Shop {
    private final UUID id;
    private final String name;
    private String displayName;
    private ShopType shopType;
    private QueueType queueType;
    private final List<ShopItem> items;
    private boolean receptionEnabled;
    private int shopTimeout;
    private int afkKickTime;
    private boolean cashCounterEnabled;
    private int cashCounterCount;
    private int baseCheckoutTime;
    private int timePerItem;

    public enum ShopType {
        BUY_ONLY, SELL_ONLY, BUY_SELL
    }

    public enum QueueType {
        RECEPTION, CASH_COUNTER, NONE
    }

    public Shop(String name, String displayName, ShopType shopType) {
        this.id = UUID.randomUUID();
        this.name = name;
        this.displayName = displayName;
        this.shopType = shopType;
        this.items = new ArrayList<>();
        this.queueType = QueueType.RECEPTION;
        this.receptionEnabled = true;
        this.shopTimeout = 60;
        this.afkKickTime = 120;
        this.cashCounterEnabled = false;
        this.cashCounterCount = 3;
        this.baseCheckoutTime = 5;
        this.timePerItem = 2;
    }

    // Getters and Setters
    public UUID getId() { return id; }
    public String getName() { return name; }
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    public ShopType getShopType() { return shopType; }
    public void setShopType(ShopType shopType) { this.shopType = shopType; }
    public QueueType getQueueType() { return queueType; }
    public void setQueueType(QueueType queueType) { this.queueType = queueType; }
    public List<ShopItem> getItems() { return new ArrayList<>(items); }
    public void addItem(ShopItem item) { items.add(item); }
    public void removeItem(ShopItem item) { items.remove(item); }
    public boolean isReceptionEnabled() { return receptionEnabled; }
    public void setReceptionEnabled(boolean enabled) { this.receptionEnabled = enabled; }
    public int getShopTimeout() { return shopTimeout; }
    public void setShopTimeout(int shopTimeout) { this.shopTimeout = shopTimeout; }
    public int getAfkKickTime() { return afkKickTime; }
    public void setAfkKickTime(int afkKickTime) { this.afkKickTime = afkKickTime; }
    public boolean isCashCounterEnabled() { return cashCounterEnabled; }
    public void setCashCounterEnabled(boolean enabled) { this.cashCounterEnabled = enabled; }
    public int getCashCounterCount() { return cashCounterCount; }
    public void setCashCounterCount(int count) { this.cashCounterCount = count; }
    public int getBaseCheckoutTime() { return baseCheckoutTime; }
    public void setBaseCheckoutTime(int time) { this.baseCheckoutTime = time; }
    public int getTimePerItem() { return timePerItem; }
    public void setTimePerItem(int time) { this.timePerItem = time; }
}