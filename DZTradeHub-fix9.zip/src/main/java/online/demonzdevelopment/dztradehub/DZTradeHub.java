package online.demonzdevelopment.dztradehub;

import online.demonzdevelopment.dztradehub.api.DZTradeHubAPI;
import online.demonzdevelopment.dztradehub.commands.AuctionHouseCommand;
import online.demonzdevelopment.dztradehub.commands.TradeHubCommand;
import online.demonzdevelopment.dztradehub.data.Area;
import online.demonzdevelopment.dztradehub.data.Shop;
import online.demonzdevelopment.dztradehub.database.DatabaseManager;
import online.demonzdevelopment.dztradehub.gui.AuctionBrowserGUI;
import online.demonzdevelopment.dztradehub.gui.ShopGUI;
import online.demonzdevelopment.dztradehub.listeners.AuctionGUIListener;
import online.demonzdevelopment.dztradehub.listeners.ShopGUIListener;
import online.demonzdevelopment.dztradehub.managers.*;
import online.demonzdevelopment.dztradehub.utils.ConfigManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;

public class DZTradeHub extends JavaPlugin {
    
    // Managers
    private ConfigManager configManager;
    private DatabaseManager databaseManager;
    private ShopManager shopManager;
    private PermissionManager permissionManager;
    private KitManager kitManager;
    private AuctionManager auctionManager;
    private QueueManager queueManager;
    private CasinoManager casinoManager;
    private BountyManager bountyManager;
    private online.demonzdevelopment.dztradehub.update.UpdateManager updateManager;
    
    // GUIs
    private ShopGUI shopGUI;
    private AuctionBrowserGUI auctionBrowserGUI;
    private online.demonzdevelopment.dztradehub.gui.BountyGUI bountyGUI;
    
    // API
    private DZTradeHubAPI api;
    private online.demonzdevelopment.dzeconomy.api.DZEconomyAPI economyAPI;
    
    @Override
    public void onEnable() {
        getLogger().info("§6========================================");
        getLogger().info("§e  DZTradeHub v1.0.0");
        getLogger().info("§e  Developer: DemonZDev");
        getLogger().info("§6========================================");
        
        // Check for DZEconomy
        if (!setupEconomy()) {
            getLogger().severe("DZEconomy not found! Disabling plugin...");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        
        // Initialize managers
        configManager = new ConfigManager(this);
        databaseManager = new DatabaseManager(this);
        shopManager = new ShopManager(this);
        permissionManager = new PermissionManager(this);
        kitManager = new KitManager(this);
        auctionManager = new AuctionManager(this);
        queueManager = new QueueManager(this);
        casinoManager = new CasinoManager(this);
        bountyManager = new BountyManager(this);
        updateManager = new online.demonzdevelopment.dztradehub.update.UpdateManager(this);
        
        // Initialize GUIs
        shopGUI = new ShopGUI(this);
        auctionBrowserGUI = new AuctionBrowserGUI(this);
        bountyGUI = new online.demonzdevelopment.dztradehub.gui.BountyGUI(this);
        
        // Initialize API
        api = new DZTradeHubAPI(this);
        
        // Register commands
        getCommand("dzth").setExecutor(new TradeHubCommand(this));
        getCommand("ah").setExecutor(new AuctionHouseCommand(this));
        getCommand("casino").setExecutor(new online.demonzdevelopment.dztradehub.commands.CasinoCommand(this));
        getCommand("coinflip").setExecutor(new online.demonzdevelopment.dztradehub.commands.CoinFlipCommand(this));
        getCommand("bounty").setExecutor(new online.demonzdevelopment.dztradehub.commands.BountyCommand(this));
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new ShopGUIListener(this), this);
        getServer().getPluginManager().registerEvents(new AuctionGUIListener(this), this);
        getServer().getPluginManager().registerEvents(new online.demonzdevelopment.dztradehub.listeners.CasinoGUIListener(this), this);
        getServer().getPluginManager().registerEvents(new online.demonzdevelopment.dztradehub.listeners.BountyListener(this), this);
        
        // Setup example shops (for demonstration)
        setupExampleShops();
        
        // Start scheduled tasks
        startScheduledTasks();
        
        getLogger().info("§aDZTradeHub enabled successfully!");
    }
    
    @Override
    public void onDisable() {
        // Close database connections
        if (databaseManager != null) {
            databaseManager.close();
        }
        
        getLogger().info("§cDZTradeHub disabled!");
    }
    
    private boolean setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("DZEconomy") == null) {
            return false;
        }
        
        try {
            economyAPI = Bukkit.getServicesManager()
                .getRegistration(online.demonzdevelopment.dzeconomy.api.DZEconomyAPI.class)
                .getProvider();
            getLogger().info("§aSuccessfully hooked into DZEconomy!");
            return true;
        } catch (Exception e) {
            getLogger().severe("Failed to hook into DZEconomy: " + e.getMessage());
            return false;
        }
    }
    
    private void setupExampleShops() {
        // Create Bazar area
        Area bazar = new Area(
            "Bazar",
            "§6§lBazar Market",
            Area.AreaType.BAZAR,
            new Location(getServer().getWorlds().get(0), 100, 64, -50)
        );
        bazar.setDescription(java.util.List.of(
            "§7Multiple shops",
            "§7with affordable prices"
        ));
        shopManager.registerArea(bazar);
        
        // Create MeatShop in Bazar
        Shop meatShop = new Shop("MeatShop", "§c§lMeat Shop", Shop.ShopType.BUY_SELL);
        meatShop.setReceptionEnabled(true);
        meatShop.setQueueType(Shop.QueueType.RECEPTION);
        shopManager.registerShop("Bazar", meatShop);
        
        // Create SuperMarket area
        Area superMarket = new Area(
            "SuperMarket",
            "§a§lSuper Market",
            Area.AreaType.SUPERMARKET,
            new Location(getServer().getWorlds().get(0), 200, 64, -100)
        );
        superMarket.setDescription(java.util.List.of(
            "§7Large stores with",
            "§7everything you need"
        ));
        shopManager.registerArea(superMarket);
        
        // Create BlockShop in SuperMarket
        Shop blockShop = new Shop("BlockShop", "§e§lBlock Shop", Shop.ShopType.BUY_ONLY);
        blockShop.setCashCounterEnabled(true);
        blockShop.setQueueType(Shop.QueueType.CASH_COUNTER);
        shopManager.registerShop("SuperMarket", blockShop);
        
        getLogger().info("§aExample shops created successfully!");
    }
    
    private void startScheduledTasks() {
        // Update auction prices every hour
        getServer().getScheduler().runTaskTimer(this, () -> {
            auctionManager.updatePrices();
        }, 0L, 72000L); // 72000 ticks = 1 hour
        
        // Check expired auctions every 6 hours
        getServer().getScheduler().runTaskTimer(this, () -> {
            auctionManager.checkExpiredAuctions();
        }, 0L, 432000L); // 432000 ticks = 6 hours
        
        getLogger().info("§aScheduled tasks started!");
    }
    
    // Getters for managers
    public ConfigManager getConfigManager() { return configManager; }
    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public ShopManager getShopManager() { return shopManager; }
    public PermissionManager getPermissionManager() { return permissionManager; }
    public KitManager getKitManager() { return kitManager; }
    public AuctionManager getAuctionManager() { return auctionManager; }
    public QueueManager getQueueManager() { return queueManager; }
    public CasinoManager getCasinoManager() { return casinoManager; }
    public BountyManager getBountyManager() { return bountyManager; }
    public online.demonzdevelopment.dztradehub.update.UpdateManager getUpdateManager() { return updateManager; }
    
    // Getters for GUIs
    public ShopGUI getShopGUI() { return shopGUI; }
    public AuctionBrowserGUI getAuctionBrowserGUI() { return auctionBrowserGUI; }
    public online.demonzdevelopment.dztradehub.gui.BountyGUI getBountyGUI() { return bountyGUI; }
    
    // Getters for APIs
    public DZTradeHubAPI getAPI() { return api; }
    public online.demonzdevelopment.dzeconomy.api.DZEconomyAPI getEconomyAPI() { return economyAPI; }
}
