package online.demonzdevelopment.dztradehub.managers;

import online.demonzdevelopment.dztradehub.DZTradeHub;
import online.demonzdevelopment.dztradehub.data.Auction;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class AuctionManager {
    private final DZTradeHub plugin;
    private final Map<UUID, Auction> auctions;
    private final Map<UUID, List<UUID>> playerListings; // playerUUID -> list of auction IDs

    public AuctionManager(DZTradeHub plugin) {
        this.plugin = plugin;
        this.auctions = new ConcurrentHashMap<>();
        this.playerListings = new ConcurrentHashMap<>();
    }

    public void createAuction(Auction auction) {
        auctions.put(auction.getId(), auction);
        playerListings.computeIfAbsent(auction.getSellerUUID(), k -> new ArrayList<>())
                      .add(auction.getId());
        plugin.getLogger().info("Created auction: " + auction.getId());
    }

    public Auction getAuction(UUID auctionId) {
        return auctions.get(auctionId);
    }

    public List<Auction> getAllAuctions() {
        return new ArrayList<>(auctions.values());
    }

    public List<Auction> getPlayerAuctions(UUID playerUUID) {
        List<UUID> ids = playerListings.get(playerUUID);
        if (ids == null) return new ArrayList<>();
        
        List<Auction> result = new ArrayList<>();
        for (UUID id : ids) {
            Auction auction = auctions.get(id);
            if (auction != null) {
                result.add(auction);
            }
        }
        return result;
    }

    public int getPlayerListingCount(UUID playerUUID) {
        return playerListings.getOrDefault(playerUUID, new ArrayList<>()).size();
    }

    public void cancelAuction(UUID auctionId) {
        Auction auction = auctions.remove(auctionId);
        if (auction != null) {
            // Remove from player listings
            List<UUID> listings = playerListings.get(auction.getSellerUUID());
            if (listings != null) {
                listings.remove(auctionId);
            }
            
            // Refund all queued buyers
            auction.getQueue().forEach(entry -> {
                Player player = plugin.getServer().getPlayer(entry.playerUUID());
                if (player != null) {
                    plugin.getEconomyAPI().addCurrency(
                        entry.playerUUID(),
                        online.demonzdevelopment.dzeconomy.currency.CurrencyType.MONEY,
                        entry.paidPrice()
                    );
                    player.sendMessage("§eAuction cancelled. Refunded: $" + entry.paidPrice());
                }
            });
            
            plugin.getLogger().info("Cancelled auction: " + auctionId);
        }
    }

    public void updatePrices() {
        auctions.values().forEach(auction -> {
            if (!auction.isFrozen() && auction.getDropPerUnit() > 0) {
                double newPrice = auction.getCurrentPrice();
                if (newPrice != auction.getActualPrice()) {
                    auction.updatePriceAfterDrop();
                    plugin.getLogger().info("Updated auction " + auction.getId() + " price to: $" + newPrice);
                }
            }
        });
    }

    public void purchaseAuction(Player buyer, Auction auction) {
        double currentPrice = auction.getCurrentPrice();
        
        // Check if it's a bidding queue auction
        if (auction.getMaxQueue() > 0) {
            // Add to queue
            auction.addToQueue(buyer.getUniqueId(), currentPrice);
            
            // Check if queue is full
            if (auction.isQueueFull()) {
                // Increase price
                auction.increasePriceAfterQueueFill();
                buyer.sendMessage("§eQueue full! Price increased to: $" + auction.getActualPrice());
            }
        } else {
            // Direct purchase (price reduction auction)
            // Remove auction
            auctions.remove(auction.getId());
            
            // Remove from player listings
            List<UUID> listings = playerListings.get(auction.getSellerUUID());
            if (listings != null) {
                listings.remove(auction.getId());
            }
            
            // Give item to buyer
            buyer.getInventory().addItem(auction.getItemStack());
            
            // Pay seller
            Player seller = plugin.getServer().getPlayer(auction.getSellerUUID());
            if (seller != null) {
                seller.sendMessage("§aYour auction sold for: $" + currentPrice);
            }
            
            buyer.sendMessage("§aPurchased item for: $" + currentPrice);
        }
    }

    public void checkExpiredAuctions() {
        long now = System.currentTimeMillis();
        List<UUID> toRemove = new ArrayList<>();
        
        auctions.values().forEach(auction -> {
            // Check if auction has been running for too long (e.g., 7 days)
            long elapsed = now - auction.getCreatedTime();
            if (elapsed > (7 * 24 * 60 * 60 * 1000)) {
                // Return item to seller
                Player seller = plugin.getServer().getPlayer(auction.getSellerUUID());
                if (seller != null) {
                    seller.getInventory().addItem(auction.getItemStack());
                    seller.sendMessage("§eYour auction expired. Item returned.");
                }
                toRemove.add(auction.getId());
            }
        });
        
        toRemove.forEach(this::cancelAuction);
    }
}