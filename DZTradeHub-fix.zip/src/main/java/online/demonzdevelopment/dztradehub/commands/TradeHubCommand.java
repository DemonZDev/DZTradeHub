package online.demonzdevelopment.dztradehub.commands;

import online.demonzdevelopment.dztradehub.DZTradeHub;
import online.demonzdevelopment.dztradehub.data.Shop;
import online.demonzdevelopment.dztradehub.data.ShopItem;
import online.demonzdevelopment.dztradehub.utils.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

public class TradeHubCommand implements CommandExecutor {
    private final DZTradeHub plugin;

    public TradeHubCommand(DZTradeHub plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, 
                           @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("dztradehub.admin")) {
            MessageUtil.send((Player) sender, "<red>You don't have permission to use this command!");
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "set-hand-item" -> handleSetHandItem(sender, args);
            case "set-buy-price" -> handleSetBuyPrice(sender, args);
            case "set-sell-price" -> handleSetSellPrice(sender, args);
            case "add-item" -> handleAddItem(sender);
            case "credit" -> handleCredit(sender);
            case "update" -> handleUpdate(sender);
            case "reload" -> handleReload(sender);
            default -> sendHelp(sender);
        }

        return true;
    }

    private void handleSetHandItem(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return;
        }

        if (args.length < 5) {
            MessageUtil.sendError(player, "Usage: /dzth set-hand-item <area> <shop> <buy_price> <sell_price>");
            return;
        }

        String areaName = args[1];
        String shopName = args[2];
        double buyPrice, sellPrice;

        try {
            buyPrice = Double.parseDouble(args[3]);
            sellPrice = Double.parseDouble(args[4]);
        } catch (NumberFormatException e) {
            MessageUtil.sendError(player, "Invalid price format!");
            return;
        }

        ItemStack handItem = player.getInventory().getItemInMainHand();
        if (handItem.getType().isAir()) {
            MessageUtil.sendError(player, "You must hold an item in your hand!");
            return;
        }

        Shop shop = plugin.getShopManager().getShop(areaName, shopName);
        if (shop == null) {
            MessageUtil.sendError(player, "Shop not found: " + areaName + "/" + shopName);
            return;
        }

        ShopItem shopItem = new ShopItem(handItem, buyPrice, sellPrice);
        plugin.getShopManager().addItemToShop(areaName, shopName, shopItem);
        
        MessageUtil.sendSuccess(player, "Added " + handItem.getType().name() + " to " + shopName);
        MessageUtil.sendInfo(player, "Buy: $" + buyPrice + " | Sell: $" + sellPrice);
    }

    private void handleSetBuyPrice(CommandSender sender, String[] args) {
        MessageUtil.send((Player) sender, "<yellow>Set buy price command - Not yet implemented");
    }

    private void handleSetSellPrice(CommandSender sender, String[] args) {
        MessageUtil.send((Player) sender, "<yellow>Set sell price command - Not yet implemented");
    }

    private void handleAddItem(CommandSender sender) {
        MessageUtil.send((Player) sender, "<yellow>Add item GUI - Not yet implemented");
    }

    private void handleCredit(CommandSender sender) {
        sender.sendMessage("§6§l========== DZTradeHub Credits ==========");
        sender.sendMessage("§e Plugin: §fDZTradeHub v1.0.0");
        sender.sendMessage("§e Developer: §fDemonZDev");
        sender.sendMessage("§e Repository: §bhttps://github.com/DemonZDev/DZTradeHub");
        sender.sendMessage("§e Economy: §fDZEconomy Integration");
        sender.sendMessage("§e Platform: §fPaperMC 1.21.1");
        sender.sendMessage("§6§l========================================");
    }

    private void handleUpdate(CommandSender sender) {
        MessageUtil.send((Player) sender, "<yellow>Checking for updates...");
        MessageUtil.send((Player) sender, "<green>You are running the latest version: 1.0.0");
    }

    private void handleReload(CommandSender sender) {
        plugin.getConfigManager().reloadConfigs();
        plugin.getPermissionManager().loadRanks();
        plugin.getKitManager().loadKits();
        MessageUtil.send((Player) sender, "<green>Configuration reloaded successfully!");
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("§6§lDZTradeHub Commands:");
        sender.sendMessage("§e/dzth set-hand-item <area> <shop> <buy> <sell> §7- Add item from hand");
        sender.sendMessage("§e/dzth set-buy-price <area> <shop> <id> <price> §7- Set buy price");
        sender.sendMessage("§e/dzth set-sell-price <area> <shop> <id> <price> §7- Set sell price");
        sender.sendMessage("§e/dzth add-item §7- Open item setup GUI");
        sender.sendMessage("§e/dzth credit §7- Show plugin credits");
        sender.sendMessage("§e/dzth update §7- Check for updates");
        sender.sendMessage("§e/dzth reload §7- Reload configurations");
    }
}